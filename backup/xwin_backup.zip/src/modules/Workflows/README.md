# Módulo Workflows - xWin Dash

## 📋 Visão Geral

O módulo Workflows é um sistema completo de automação de processos de negócio através de workflows visuais com integração NodeRed. Este módulo foi refatorado seguindo os mais altos padrões de qualidade e arquitetura.

## 🏗️ Arquitetura

### Estrutura de Pastas

```
Workflows/
├── index.tsx                    # Entry point otimizado
├── types/                       # Definições de tipos
│   ├── index.ts
│   ├── workflowTypes.ts         # Tipos principais
│   ├── workflowInterfaces.ts    # Interfaces
│   ├── workflowEnums.ts         # Enums
│   └── workflowExecutionTypes.ts # Tipos de execução
├── hooks/                       # Stores e hooks
│   ├── index.ts
│   ├── useWorkflowsStore.ts     # Store principal
│   ├── useExecutionsStore.ts    # Store de execuções
│   ├── useQueueStore.ts         # Store de filas
│   ├── useMetricsStore.ts       # Store de métricas
│   └── useFiltersStore.ts       # Store de filtros
├── services/                    # Camada de serviços
│   ├── index.ts
│   ├── workflowsService.ts      # Service orquestrador
│   ├── workflowManagementService.ts
│   ├── workflowExecutionService.ts
│   ├── workflowQueueService.ts
│   ├── workflowMetricsService.ts
│   ├── workflowTemplatesService.ts
│   ├── workflowValidationService.ts
│   ├── workflowNodeRedService.ts
│   └── workflowCanvasService.ts
├── components/                  # Componentes React
│   ├── index.ts
│   ├── WorkflowsDashboard.tsx   # Dashboard principal
│   ├── WorkflowsStats.tsx       # Estatísticas
│   ├── WorkflowsFilters.tsx     # Filtros
│   ├── WorkflowsList.tsx        # Lista de workflows
│   ├── WorkflowsGrid.tsx        # Grid de workflows
│   ├── WorkflowsActions.tsx     # Ações em lote
│   ├── WorkflowsCreateModal.tsx # Modal de criação
│   ├── WorkflowsIntegrationTest.tsx # Testes de integração
│   └── WorkflowsLazyComponents.tsx # Componentes lazy
├── utils/                       # Utilitários
│   ├── workflowCache.ts         # Sistema de cache
│   └── workflowValidation.ts    # Sistema de validação
├── tests/                       # Testes
│   └── workflows.test.ts        # Testes unitários
└── README.md                    # Esta documentação
```

## 🚀 Funcionalidades

### 1. Gerenciamento de Workflows
- ✅ CRUD completo de workflows
- ✅ Validação em tempo real
- ✅ Templates pré-definidos
- ✅ Duplicação de workflows
- ✅ Ativação/desativação

### 2. Execução de Workflows
- ✅ Execução manual e automática
- ✅ Controle de execução (pausar, retomar, cancelar)
- ✅ Monitoramento em tempo real
- ✅ Retry automático
- ✅ Timeout configurável

### 3. Sistema de Filas
- ✅ Gerenciamento de filas de execução
- ✅ Priorização de workflows
- ✅ Processamento em lote
- ✅ Monitoramento de status

### 4. Métricas e Analytics
- ✅ Estatísticas de execução
- ✅ Métricas de performance
- ✅ Relatórios detalhados
- ✅ Dashboards em tempo real

### 5. Integração NodeRed
- ✅ Conexão com NodeRed
- ✅ Sincronização de workflows
- ✅ Monitoramento de status
- ✅ Gerenciamento de fluxos

### 6. Canvas de Workflow
- ✅ Editor visual
- ✅ Otimização de layout
- ✅ Validação de estrutura
- ✅ Exportação/importação

## 🛠️ Como Usar

### 1. Importação Básica

```typescript
import { WorkflowsDashboard } from '@/modules/Workflows/components';
import { useWorkflowsStore } from '@/modules/Workflows/hooks';
import { workflowsService } from '@/modules/Workflows/services';
```

### 2. Uso do Dashboard

```tsx
import React from 'react';
import { WorkflowsDashboard } from '@/modules/Workflows/components';

const MyWorkflowsPage = () => {
  return (
    <WorkflowsDashboard
      showAdvancedFeatures={true}
      defaultView="grid"
      autoRefresh={true}
      refreshInterval={30000}
    />
  );
};
```

### 3. Uso dos Stores

```tsx
import { useWorkflowsStore, useExecutionsStore } from '@/modules/Workflows/hooks';

const MyComponent = () => {
  const {
    workflows,
    loading,
    error,
    fetchWorkflows,
    createWorkflow
  } = useWorkflowsStore();

  const {
    executions,
    executeWorkflow,
    stopExecution
  } = useExecutionsStore();

  // Usar os dados e ações...
};
```

### 4. Uso dos Services

```typescript
import { workflowsService } from '@/modules/Workflows/services';

// Buscar workflows
const workflows = await workflowsService.getWorkflows({
  page: 1,
  limit: 10,
  search: 'meu workflow'
});

// Criar workflow
const newWorkflow = await workflowsService.createWorkflow({
  name: 'Novo Workflow',
  description: 'Descrição do workflow',
  trigger: { type: 'webhook' },
  steps: []
});

// Executar workflow
const execution = await workflowsService.executeWorkflow({
  workflow_id: 1,
  variables: { param1: 'value1' }
});
```

### 5. Validação de Workflows

```typescript
import { workflowValidator, validationUtils } from '@/modules/Workflows/utils/workflowValidation';

// Validar workflow completo
const result = workflowValidator.validateObject(workflow);

if (!result.isValid) {
  console.log('Erros:', validationUtils.formatErrors(result.errors));
  console.log('Warnings:', validationUtils.formatErrors(result.warnings));
}

// Validar campo específico
const fieldResult = workflowValidator.validateField('name', 'Meu Workflow');
```

### 6. Sistema de Cache

```typescript
import { workflowCache, cacheUtils } from '@/modules/Workflows/utils/workflowCache';

// Armazenar no cache
workflowCache.set('workflow-1', workflowData, 300000); // 5 minutos

// Recuperar do cache
const cached = workflowCache.get('workflow-1');

// Estatísticas do cache
const stats = workflowCache.getStats();
console.log('Taxa de acerto:', stats.hitRate);
```

## 🎯 Componentes Principais

### WorkflowsDashboard
Dashboard principal que integra todos os subcomponentes.

**Props:**
- `showAdvancedFeatures?: boolean` - Mostra recursos avançados
- `defaultView?: 'grid' | 'list'` - Visualização padrão
- `autoRefresh?: boolean` - Auto refresh habilitado
- `refreshInterval?: number` - Intervalo de refresh em ms

### WorkflowsStats
Exibe estatísticas e métricas de workflows.

**Props:**
- `stats?: ExecutionStats` - Estatísticas de execução
- `systemMetrics?: SystemMetrics` - Métricas do sistema
- `loading?: boolean` - Estado de loading
- `showSystemMetrics?: boolean` - Mostra métricas do sistema

### WorkflowsFilters
Sistema de filtros avançados.

**Props:**
- `filters: WorkflowFilters` - Filtros atuais
- `onFiltersChange: (filters) => void` - Callback de mudança
- `onClearFilters: () => void` - Callback de limpeza
- `showAdvancedFilters?: boolean` - Mostra filtros avançados

### WorkflowsList
Lista de workflows em formato de tabela.

**Props:**
- `workflows: Workflow[]` - Lista de workflows
- `pagination: WorkflowPagination` - Informações de paginação
- `selection: WorkflowSelection` - Estado de seleção
- `onWorkflowSelect: (id) => void` - Callback de seleção
- `onWorkflowAction: (id, action) => void` - Callback de ação

### WorkflowsGrid
Grid de workflows em formato de cards.

**Props:**
- `workflows: Workflow[]` - Lista de workflows
- `gridCols?: 1 | 2 | 3 | 4` - Número de colunas
- `showStats?: boolean` - Mostra estatísticas nos cards

## 🔧 Configuração

### 1. Configuração de Cache

```typescript
import { workflowCache } from '@/modules/Workflows/utils/workflowCache';

// Configurar TTL padrão
workflowCache.set('config', { defaultTTL: 600000 }); // 10 minutos
```

### 2. Configuração de Validação

```typescript
import { workflowValidator } from '@/modules/Workflows/utils/workflowValidation';

// Adicionar regra customizada
workflowValidator.addRules('custom_field', [
  {
    name: 'custom_rule',
    message: 'Valor customizado inválido',
    validate: (value) => value !== 'invalid',
    severity: 'error'
  }
]);
```

### 3. Configuração de Services

```typescript
import { workflowsService } from '@/modules/Workflows/services';

// Atualizar configuração
workflowsService.updateConfig({
  cache_enabled: true,
  cache_ttl: 300000,
  retry_attempts: 3,
  auto_sync_nodered: true
});
```

## 🧪 Testes

### Executar Testes

```bash
# Testes unitários
npm test workflows.test.ts

# Testes com cobertura
npm run test:coverage

# Testes de integração
npm run test:integration
```

### Estrutura de Testes

- **Services**: Testes de API e lógica de negócio
- **Stores**: Testes de estado e ações
- **Components**: Testes de renderização e interação
- **Utils**: Testes de utilitários e validação
- **Integration**: Testes de fluxo completo

## 📊 Performance

### Otimizações Implementadas

1. **Lazy Loading**: Componentes carregados sob demanda
2. **Memoização**: React.memo, useMemo, useCallback
3. **Cache Inteligente**: TTL configurável e invalidação automática
4. **Debouncing**: Validação em tempo real otimizada
5. **Virtual Scrolling**: Para listas grandes
6. **Code Splitting**: Divisão de código por funcionalidade

### Métricas de Performance

- **Tempo de carregamento inicial**: < 2s
- **Tempo de resposta da API**: < 500ms
- **Taxa de acerto do cache**: > 80%
- **Tempo de validação**: < 50ms
- **Bundle size**: < 500KB (gzipped)

## 🔒 Segurança

### Validação de Dados
- Validação de entrada em todos os endpoints
- Sanitização de dados do usuário
- Validação de tipos TypeScript

### Controle de Acesso
- Verificação de permissões
- Validação de tokens
- Rate limiting

### Auditoria
- Log de todas as ações
- Rastreamento de mudanças
- Histórico de execuções

## 🚀 Deploy

### Build de Produção

```bash
# Build otimizado
npm run build

# Análise do bundle
npm run analyze
```

### Variáveis de Ambiente

```env
# API Configuration
REACT_APP_API_BASE_URL=https://api.xwindash.com
REACT_APP_API_TIMEOUT=30000

# Cache Configuration
REACT_APP_CACHE_TTL=300000
REACT_APP_CACHE_MAX_SIZE=1000

# NodeRed Integration
REACT_APP_NODERED_URL=http://localhost:1880
REACT_APP_NODERED_API_KEY=your-api-key
```

## 📈 Monitoramento

### Métricas Disponíveis

- **Execuções por minuto**
- **Taxa de sucesso/falha**
- **Tempo médio de execução**
- **Uso de recursos**
- **Erros por tipo**

### Alertas

- **Falhas de execução > 10%**
- **Tempo de resposta > 5s**
- **Uso de CPU > 80%**
- **Uso de memória > 90%**

## 🤝 Contribuição

### Padrões de Código

1. **TypeScript**: Tipagem completa
2. **ESLint**: Linting automático
3. **Prettier**: Formatação consistente
4. **JSDoc**: Documentação de funções
5. **Testes**: Cobertura > 80%

### Processo de Contribuição

1. Fork do repositório
2. Criar branch feature
3. Implementar com testes
4. Pull request com descrição
5. Code review
6. Merge após aprovação

## 📚 Recursos Adicionais

### Documentação
- [API Reference](./docs/api.md)
- [Component Library](./docs/components.md)
- [Architecture Guide](./docs/architecture.md)
- [Troubleshooting](./docs/troubleshooting.md)

### Exemplos
- [Basic Usage](./examples/basic-usage.tsx)
- [Advanced Features](./examples/advanced-features.tsx)
- [Custom Components](./examples/custom-components.tsx)
- [Integration Examples](./examples/integration.tsx)

### Comunidade
- [GitHub Issues](https://github.com/xwindash/workflows/issues)
- [Discord Community](https://discord.gg/xwindash)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/xwindash)

## 📄 Licença

Este módulo é parte do xWin Dash e está licenciado sob a [MIT License](../../LICENSE).

---

**Desenvolvido com ❤️ pela equipe xWin Dash**