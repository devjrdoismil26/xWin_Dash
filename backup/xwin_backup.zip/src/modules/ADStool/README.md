# Módulo ADStool

## Visão Geral

O módulo **ADStool** é responsável por gerenciar campanhas de anúncios, contas de publicidade e criativos em múltiplas plataformas. Ele fornece uma interface unificada para gerenciar Google Ads, Facebook Ads, Instagram Ads e outras plataformas de publicidade.

## Estrutura

```
ADStool/
├── index.tsx                    # Entry point principal (máx. 100 linhas)
├── types/                       # Definições de tipos TypeScript
│   ├── index.ts
│   ├── adsAccount.ts
│   ├── adsCampaign.ts
│   ├── adsCreative.ts
│   ├── adsAnalytics.ts
│   └── adsTemplate.ts
├── services/                    # Camada de serviços
│   ├── index.ts
│   ├── adsService.ts           # Orquestrador principal
│   ├── adsAccountService.ts    # Gerenciamento de contas
│   ├── adsCampaignService.ts   # Gerenciamento de campanhas
│   ├── adsCreativeService.ts   # Gerenciamento de criativos
│   ├── adsAnalyticsService.ts  # Analytics e relatórios
│   └── adsTemplateService.ts   # Templates e otimizações
├── hooks/                       # Hooks customizados
│   ├── index.ts
│   ├── useADStool.ts          # Hook principal
│   └── useADStoolStore.ts     # Estado global
├── components/                  # Componentes React
│   ├── index.ts
│   ├── ADStoolHeader.tsx      # Cabeçalho principal
│   ├── ADStoolStats.tsx       # Estatísticas
│   ├── ADStoolFeatures.tsx    # Grid de funcionalidades
│   ├── ADStoolQuickActions.tsx # Ações rápidas
│   ├── ADStoolConnectedAccounts.tsx # Contas conectadas
│   ├── ADStoolRecentCampaigns.tsx # Campanhas recentes
│   ├── ADStoolGettingStarted.tsx # Guia de início
│   ├── AdvancedADSToolDashboard.tsx # Dashboard avançado
│   └── ADStoolIntegrationTest.tsx # Teste de integração
├── pages/                       # Páginas do módulo
│   ├── index.ts
│   ├── ADStoolIndexPage.tsx   # Página principal
│   ├── ADStoolDetailPage.tsx  # Página de detalhes
│   └── ADStoolCreatePage.tsx  # Página de criação
├── tests/                       # Testes
│   ├── adstool.test.ts        # Testes unitários
│   ├── adstool.integration.test.ts # Testes de integração
│   └── __mocks__/
│       └── adsService.ts      # Mocks para testes
├── utils/                       # Funções utilitárias
│   ├── index.ts
│   ├── formatters.ts          # Formatação de dados
│   ├── calculations.ts        # Cálculos de métricas
│   └── validators.ts          # Validações
└── README.md                   # Esta documentação
```

## Funcionalidades Principais

### 1. Gerenciamento de Contas
- Conectar contas de múltiplas plataformas
- Visualizar status e saldo das contas
- Gerenciar permissões e configurações

### 2. Gerenciamento de Campanhas
- Criar, editar e excluir campanhas
- Configurar orçamentos e targeting
- Monitorar performance em tempo real

### 3. Gerenciamento de Criativos
- Criar e gerenciar anúncios
- Upload de mídia (imagens, vídeos)
- A/B testing de criativos

### 4. Analytics e Relatórios
- Métricas de performance
- Relatórios personalizados
- Exportação de dados

### 5. Templates e Otimizações
- Templates pré-configurados
- Sugestões de otimização
- Automação de campanhas

## Uso

### Hook Principal

```typescript
import { useADStool } from '@/modules/ADStool';

const MyComponent = () => {
  const {
    campaigns,
    accounts,
    loading,
    fetchCampaigns,
    fetchAccounts,
    getTotalSpend,
    getTotalImpressions,
    getTotalClicks,
    formatCurrency,
    formatPercentage
  } = useADStool();

  useEffect(() => {
    fetchCampaigns();
    fetchAccounts();
  }, []);

  return (
    <div>
      <h2>Total Gasto: {formatCurrency(getTotalSpend())}</h2>
      <h2>Total Impressões: {getTotalImpressions()}</h2>
      <h2>Total Cliques: {getTotalClicks()}</h2>
    </div>
  );
};
```

### Serviços

```typescript
import { adsService } from '@/modules/ADStool';

// Buscar campanhas
const campaigns = await adsService.campaigns.getCampaigns();

// Criar nova campanha
const newCampaign = await adsService.campaigns.createCampaign({
  name: 'Nova Campanha',
  platform: 'Google Ads',
  daily_budget: 100
});

// Buscar analytics
const analytics = await adsService.analytics.getAnalytics();
```

### Componentes

```typescript
import {
  ADStoolHeader,
  ADStoolStats,
  ADStoolFeatures
} from '@/modules/ADStool/components';

const Dashboard = () => {
  return (
    <div>
      <ADStoolHeader 
        onAdvancedDashboard={() => {}}
        onIntegrationTest={() => {}}
      />
      <ADStoolStats 
        campaigns={campaigns}
        activeCampaigns={activeCampaigns}
        pausedCampaigns={pausedCampaigns}
        getTotalSpend={getTotalSpend}
        getTotalImpressions={getTotalImpressions}
        getTotalClicks={getTotalClicks}
        getAverageCTR={getAverageCTR}
        formatPercentage={formatPercentage}
      />
      <ADStoolFeatures 
        campaigns={campaigns}
        accounts={accounts}
      />
    </div>
  );
};
```

## API

### useADStool Hook

#### Estado
- `campaigns: AdsCampaign[]` - Lista de campanhas
- `accounts: AdsAccount[]` - Lista de contas
- `loading: boolean` - Estado de carregamento

#### Métodos
- `fetchCampaigns()` - Buscar campanhas
- `fetchAccounts()` - Buscar contas
- `fetchAnalyticsSummary()` - Buscar resumo de analytics

#### Métricas
- `getTotalSpend()` - Gasto total
- `getTotalImpressions()` - Total de impressões
- `getTotalClicks()` - Total de cliques
- `getTotalConversions()` - Total de conversões
- `getAverageCTR()` - CTR médio
- `getAverageCPC()` - CPC médio

#### Filtros
- `getActiveCampaigns()` - Campanhas ativas
- `getPausedCampaigns()` - Campanhas pausadas
- `getConnectedAccounts()` - Contas conectadas

#### Formatação
- `formatCurrency(value)` - Formatar moeda
- `formatNumber(value)` - Formatar números
- `formatPercentage(value)` - Formatar percentuais

### adsService

#### Contas
- `adsService.accounts.getAccounts()` - Listar contas
- `adsService.accounts.createAccount(data)` - Criar conta
- `adsService.accounts.updateAccount(id, data)` - Atualizar conta
- `adsService.accounts.deleteAccount(id)` - Excluir conta

#### Campanhas
- `adsService.campaigns.getCampaigns()` - Listar campanhas
- `adsService.campaigns.createCampaign(data)` - Criar campanha
- `adsService.campaigns.updateCampaign(id, data)` - Atualizar campanha
- `adsService.campaigns.deleteCampaign(id)` - Excluir campanha

#### Criativos
- `adsService.creatives.getCreatives()` - Listar criativos
- `adsService.creatives.createCreative(data)` - Criar criativo
- `adsService.creatives.updateCreative(id, data)` - Atualizar criativo
- `adsService.creatives.deleteCreative(id)` - Excluir criativo

#### Analytics
- `adsService.analytics.getAnalytics()` - Analytics gerais
- `adsService.analytics.getCampaignAnalytics(id)` - Analytics de campanha
- `adsService.analytics.getAccountAnalytics(id)` - Analytics de conta

#### Templates
- `adsService.templates.getTemplates()` - Listar templates
- `adsService.templates.createTemplate(data)` - Criar template
- `adsService.templates.applyTemplate(id, data)` - Aplicar template

## Tipos

### AdsAccount
```typescript
interface AdsAccount {
  id: string;
  name: string;
  platform: AdsPlatform;
  status: AdsAccountStatus;
  balance: number;
  currency: string;
  timezone: string;
  created_at: string;
  updated_at: string;
}
```

### AdsCampaign
```typescript
interface AdsCampaign {
  id: string;
  name: string;
  status: AdsCampaignStatus;
  platform: AdsPlatform;
  objective: AdsObjective;
  daily_budget: number;
  total_budget?: number;
  targeting: AdsTargeting;
  start_date: string;
  end_date?: string;
  created_at: string;
  updated_at: string;
}
```

### AdsCreative
```typescript
interface AdsCreative {
  id: string;
  name: string;
  type: AdsCreativeType;
  status: AdsCreativeStatus;
  platform: AdsPlatform;
  content: AdsCreativeContent;
  campaign_id: string;
  created_at: string;
  updated_at: string;
}
```

### AdsAnalytics
```typescript
interface AdsAnalytics {
  id: string;
  entity_type: 'campaign' | 'account' | 'creative';
  entity_id: string;
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  ctr: number;
  cpc: number;
  cpa: number;
  roi: number;
}
```

## Testes

### Executar Testes

```bash
# Testes unitários
npm test -- --testPathPattern=adstool.test.ts

# Testes de integração
npm test -- --testPathPattern=adstool.integration.test.ts

# Todos os testes do módulo
npm test -- --testPathPattern=ADStool
```

### Cobertura de Testes

```bash
npm test -- --coverage --testPathPattern=ADStool
```

## Configuração

### Variáveis de Ambiente

```env
# Google Ads API
GOOGLE_ADS_CLIENT_ID=your_client_id
GOOGLE_ADS_CLIENT_SECRET=your_client_secret
GOOGLE_ADS_REFRESH_TOKEN=your_refresh_token

# Facebook Ads API
FACEBOOK_ADS_APP_ID=your_app_id
FACEBOOK_ADS_APP_SECRET=your_app_secret
FACEBOOK_ADS_ACCESS_TOKEN=your_access_token

# Outras plataformas
LINKEDIN_ADS_CLIENT_ID=your_client_id
LINKEDIN_ADS_CLIENT_SECRET=your_client_secret
```

### Configuração de Rotas

```typescript
// routes/web.ts
Route::get('/adstool', [ADStoolController::class, 'index'])->name('adstool.index');
Route::get('/adstool/campaigns', [ADStoolController::class, 'campaigns'])->name('adstool.campaigns');
Route::get('/adstool/accounts', [ADStoolController::class, 'accounts'])->name('adstool.accounts');
Route::get('/adstool/creatives', [ADStoolController::class, 'creatives'])->name('adstool.creatives');
Route::get('/adstool/analytics', [ADStoolController::class, 'analytics'])->name('adstool.analytics');
```

## Troubleshooting

### Problemas Comuns

#### 1. Erro de Autenticação
```
Error: Invalid credentials for Google Ads API
```
**Solução:** Verifique as credenciais nas variáveis de ambiente e renove o refresh token.

#### 2. Rate Limit Exceeded
```
Error: Rate limit exceeded for Facebook Ads API
```
**Solução:** Implemente retry com backoff exponencial ou reduza a frequência das chamadas.

#### 3. Campanha não encontrada
```
Error: Campaign not found
```
**Solução:** Verifique se o ID da campanha está correto e se a campanha existe na plataforma.

### Logs

```typescript
// Habilitar logs detalhados
localStorage.setItem('adstool-debug', 'true');

// Ver logs no console
console.log('ADStool Debug:', window.adstoolDebug);
```

## Contribuição

### Padrões de Código

1. **TypeScript**: Use tipagem forte
2. **Componentes**: Máximo 200 linhas por componente
3. **Hooks**: Máximo 100 linhas por hook
4. **Services**: Máximo 300 linhas por service
5. **Testes**: Cobertura mínima de 80%

### Processo de Contribuição

1. Fork do repositório
2. Criar branch para feature
3. Implementar com testes
4. Criar Pull Request
5. Code review
6. Merge

### Checklist de PR

- [ ] Código segue padrões estabelecidos
- [ ] Testes passando
- [ ] Cobertura de testes adequada
- [ ] Documentação atualizada
- [ ] Sem breaking changes
- [ ] Performance testada

## Roadmap

### Versão 1.1
- [ ] Suporte a TikTok Ads
- [ ] Automação de campanhas
- [ ] Relatórios avançados
- [ ] Integração com BI

### Versão 1.2
- [ ] Machine Learning para otimização
- [ ] API pública
- [ ] Webhooks
- [ ] Mobile app

### Versão 2.0
- [ ] Multi-tenant
- [ ] White-label
- [ ] Enterprise features
- [ ] Advanced analytics

## Licença

Este módulo é parte do projeto xWin-Dash e está sob a mesma licença do projeto principal.

## Suporte

Para suporte técnico ou dúvidas sobre o módulo ADStool:

- **Email**: dev@xwin.com.br
- **Slack**: #adstool-support
- **Documentação**: [docs.xwin.com.br/adstool](https://docs.xwin.com.br/adstool)
- **Issues**: [GitHub Issues](https://github.com/xwin/xwin-dash/issues)

---

**Última atualização**: Janeiro 2024  
**Versão**: 1.0.0  
**Mantenedor**: Equipe de Desenvolvimento xWin