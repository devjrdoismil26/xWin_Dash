# Módulo Analytics - xWin Dash

## 📊 Visão Geral

O módulo Analytics é um sistema completo de análise de dados que oferece insights em tempo real, relatórios personalizados e integração com múltiplas fontes de dados. Desenvolvido seguindo os princípios de arquitetura limpa e padrões de maestria total.

## 🏗️ Arquitetura

### Estrutura de Pastas

```
Analytics/
├── index.tsx                    # Entry point principal (68 linhas)
├── types/                       # Definições de tipos TypeScript
│   ├── index.ts
│   ├── analyticsTypes.ts
│   ├── analyticsInterfaces.ts
│   ├── analyticsEnums.ts
│   └── analyticsProviders.ts
├── hooks/                       # Hooks especializados
│   ├── index.ts
│   ├── useAnalytics.ts          # Hook orquestrador (150 linhas)
│   ├── useAnalyticsStore.ts     # Store Zustand com TypeScript
│   ├── useAnalyticsDashboard.ts # Hook para dashboard
│   ├── useAnalyticsFilters.ts   # Hook para filtros
│   ├── useAnalyticsRealTime.ts  # Hook para tempo real
│   ├── useAnalyticsReports.ts   # Hook para relatórios
│   └── useGoogleAnalytics.ts    # Hook para Google Analytics
├── services/                    # Camada de serviços
│   ├── index.ts
│   ├── analyticsService.ts      # Orquestrador de serviços
│   ├── analyticsApiService.ts   # Serviço de API
│   ├── analyticsCacheService.ts # Serviço de cache
│   └── googleAnalyticsService.ts # Serviço do Google Analytics
├── components/                  # Componentes React
│   ├── index.ts
│   ├── AnalyticsDashboard.tsx   # Dashboard principal
│   ├── AnalyticsHeader.tsx      # Cabeçalho
│   ├── AnalyticsFilters.tsx     # Filtros
│   ├── AnalyticsMetrics.tsx     # Métricas
│   ├── AnalyticsCharts.tsx      # Gráficos
│   ├── AnalyticsInsights.tsx    # Insights
│   ├── AnalyticsReports.tsx     # Relatórios
│   ├── AnalyticsRealTime.tsx    # Tempo real
│   ├── AnalyticsExport.tsx      # Exportação
│   ├── AnalyticsActions.tsx     # Ações
│   ├── AnalyticsBreadcrumbs.tsx # Navegação
│   └── AnalyticsIntegrationTest.tsx # Teste de integração
├── pages/                       # Páginas do módulo
│   ├── index.ts
│   ├── AnalyticsIndexPage.tsx   # Página principal
│   ├── AnalyticsDetailPage.tsx  # Página de detalhes
│   └── AnalyticsCreatePage.tsx  # Página de criação
├── utils/                       # Utilitários
│   ├── index.ts
│   ├── analyticsHelpers.ts      # Funções auxiliares
│   ├── analyticsFormatters.ts   # Formatadores
│   ├── analyticsValidators.ts   # Validadores
│   └── analyticsConstants.ts    # Constantes
├── tests/                       # Testes
│   ├── analytics.test.ts        # Testes unitários
│   ├── analytics.integration.test.ts # Testes de integração
│   └── __mocks__/
│       └── analyticsService.ts  # Mock do serviço
└── README.md                    # Esta documentação
```

## 🚀 Funcionalidades

### Dashboard Principal
- **Métricas em Tempo Real**: Visualização de dados atualizados automaticamente
- **Gráficos Interativos**: Múltiplos tipos de visualização (linha, barra, pizza, área)
- **Insights Inteligentes**: Análise automática de tendências e anomalias
- **Filtros Avançados**: Filtragem por período, dispositivo, fonte de tráfego

### Relatórios
- **Criação Personalizada**: Relatórios customizáveis com filtros específicos
- **Exportação Multi-formato**: JSON, CSV, Excel, PDF
- **Agendamento**: Relatórios automáticos por email
- **Compartilhamento**: Links públicos para relatórios

### Analytics em Tempo Real
- **WebSocket Integration**: Dados atualizados instantaneamente
- **Auto-refresh**: Atualização automática configurável
- **Métricas ao Vivo**: Usuários ativos, visualizações, fontes de tráfego

### Integrações
- **Google Analytics**: Integração completa com GA4
- **Facebook Analytics**: Dados de redes sociais
- **APIs Customizadas**: Integração com sistemas próprios

## 🛠️ Tecnologias

### Frontend
- **React 18**: Biblioteca principal
- **TypeScript**: Tipagem estática
- **Zustand**: Gerenciamento de estado
- **Inertia.js**: Roteamento e páginas
- **Tailwind CSS**: Estilização
- **Lucide React**: Ícones

### Testes
- **Jest**: Framework de testes
- **React Testing Library**: Testes de componentes
- **MSW**: Mock de APIs

### Ferramentas
- **ESLint**: Linting
- **Prettier**: Formatação
- **Husky**: Git hooks

## 📖 Guia de Uso

### Instalação

```bash
# Instalar dependências
npm install

# Executar testes
npm test

# Executar em modo desenvolvimento
npm run dev

# Executar testes específicos do Analytics
npm test -- --testPathPattern=Analytics

# Executar com cobertura
npm run test:coverage -- --testPathPattern=Analytics
```

### Uso Básico

```tsx
import { Analytics } from '@/modules/Analytics';

// Página principal
<Analytics auth={auth} page="index" />

// Dashboard específico
<Analytics auth={auth} page="dashboard" />

// Relatórios
<Analytics auth={auth} page="reports" />

// Tempo real
<Analytics auth={auth} page="real-time" />
```

### Exemplos Avançados

#### Dashboard Personalizado
```tsx
import React, { useEffect, useState } from 'react';
import { useAnalytics } from '@/modules/Analytics/hooks';
import { AnalyticsDashboard, AnalyticsFilters } from '@/modules/Analytics/components';

const CustomAnalyticsPage = () => {
  const {
    dashboard,
    metrics,
    insights,
    loading,
    error,
    fetchDashboard,
    applyFilters,
    toggleRealTime,
    exportData
  } = useAnalytics();

  const [customFilters, setCustomFilters] = useState({
    date_range: '30days',
    report_type: 'overview',
    metrics: ['page_views', 'unique_visitors', 'bounce_rate']
  });

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleFilterChange = (newFilters) => {
    setCustomFilters(newFilters);
    applyFilters(newFilters);
  };

  const handleExport = async (format) => {
    try {
      await exportData(dashboard.id, format);
      console.log(`Relatório exportado em formato ${format}`);
    } catch (error) {
      console.error('Erro ao exportar:', error);
    }
  };

  if (loading) return <div>Carregando analytics...</div>;
  if (error) return <div>Erro: {error}</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Analytics Personalizado</h1>
        <div className="space-x-2">
          <button 
            onClick={() => handleExport('pdf')}
            className="px-4 py-2 bg-blue-600 text-white rounded"
          >
            Exportar PDF
          </button>
          <button 
            onClick={() => toggleRealTime()}
            className="px-4 py-2 bg-green-600 text-white rounded"
          >
            Tempo Real
          </button>
        </div>
      </div>

      <AnalyticsFilters 
        filters={customFilters}
        onFiltersChange={handleFilterChange}
      />

      <AnalyticsDashboard />
    </div>
  );
};
```

#### Métricas em Tempo Real
```tsx
import React, { useEffect } from 'react';
import { useAnalytics } from '@/modules/Analytics/hooks';

const RealTimeMetrics = () => {
  const {
    metrics,
    realTimeEnabled,
    toggleRealTime,
    refreshInterval,
    setRefreshInterval
  } = useAnalytics();

  useEffect(() => {
    if (realTimeEnabled) {
      const interval = setInterval(() => {
        // Atualização automática dos dados
        console.log('Atualizando métricas em tempo real...');
      }, refreshInterval);

      return () => clearInterval(interval);
    }
  }, [realTimeEnabled, refreshInterval]);

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Métricas em Tempo Real</h2>
        <div className="flex items-center space-x-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={realTimeEnabled}
              onChange={toggleRealTime}
              className="mr-2"
            />
            Tempo Real
          </label>
          <select
            value={refreshInterval}
            onChange={(e) => setRefreshInterval(Number(e.target.value))}
            className="px-3 py-1 border rounded"
          >
            <option value={5000}>5 segundos</option>
            <option value={10000}>10 segundos</option>
            <option value={30000}>30 segundos</option>
            <option value={60000}>1 minuto</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric) => (
          <div key={metric.type} className="bg-gray-50 p-4 rounded">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{metric.name}</h3>
              <span className={`text-sm ${
                metric.trend === 'up' ? 'text-green-600' : 
                metric.trend === 'down' ? 'text-red-600' : 'text-gray-600'
              }`}>
                {metric.change > 0 ? '+' : ''}{metric.change}%
              </span>
            </div>
            <div className="text-2xl font-bold mt-2">
              {metric.value.toLocaleString()} {metric.unit}
            </div>
            {realTimeEnabled && (
              <div className="text-xs text-green-600 mt-1">
                ● Atualizado agora
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
```

#### Relatórios Customizados
```tsx
import React, { useState } from 'react';
import { useAnalytics } from '@/modules/Analytics/hooks';

const ReportBuilder = () => {
  const {
    reports,
    createReport,
    exportReport,
    loading
  } = useAnalytics();

  const [reportData, setReportData] = useState({
    name: '',
    description: '',
    type: 'custom',
    metrics: [],
    filters: {
      date_range: '30days',
      report_type: 'overview'
    },
    schedule: null
  });

  const handleCreateReport = async () => {
    try {
      const newReport = await createReport(reportData);
      console.log('Relatório criado:', newReport);
      alert('Relatório criado com sucesso!');
    } catch (error) {
      console.error('Erro ao criar relatório:', error);
      alert('Erro ao criar relatório');
    }
  };

  const handleExportReport = async (reportId, format) => {
    try {
      await exportReport(reportId, format);
      alert(`Relatório exportado em formato ${format}`);
    } catch (error) {
      console.error('Erro ao exportar:', error);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Construtor de Relatórios</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Formulário de Criação */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Criar Novo Relatório</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nome do Relatório</label>
              <input
                type="text"
                value={reportData.name}
                onChange={(e) => setReportData({...reportData, name: e.target.value})}
                className="w-full px-3 py-2 border rounded-md"
                placeholder="Ex: Relatório Mensal de Vendas"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Descrição</label>
              <textarea
                value={reportData.description}
                onChange={(e) => setReportData({...reportData, description: e.target.value})}
                className="w-full px-3 py-2 border rounded-md"
                rows={3}
                placeholder="Descreva o propósito do relatório..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Métricas</label>
              <div className="space-y-2">
                {['page_views', 'unique_visitors', 'bounce_rate', 'conversion_rate'].map(metric => (
                  <label key={metric} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={reportData.metrics.includes(metric)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setReportData({
                            ...reportData,
                            metrics: [...reportData.metrics, metric]
                          });
                        } else {
                          setReportData({
                            ...reportData,
                            metrics: reportData.metrics.filter(m => m !== metric)
                          });
                        }
                      }}
                      className="mr-2"
                    />
                    {metric.replace('_', ' ').toUpperCase()}
                  </label>
                ))}
              </div>
            </div>

            <button
              onClick={handleCreateReport}
              disabled={loading || !reportData.name}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-md disabled:opacity-50"
            >
              {loading ? 'Criando...' : 'Criar Relatório'}
            </button>
          </div>
        </div>

        {/* Lista de Relatórios */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Relatórios Existentes</h2>
          
          <div className="space-y-3">
            {reports.map((report) => (
              <div key={report.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium">{report.name}</h3>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                    {report.type}
                  </span>
                </div>
                
                {report.description && (
                  <p className="text-sm text-gray-600 mb-3">{report.description}</p>
                )}
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleExportReport(report.id, 'pdf')}
                    className="px-3 py-1 bg-red-600 text-white text-sm rounded"
                  >
                    PDF
                  </button>
                  <button
                    onClick={() => handleExportReport(report.id, 'csv')}
                    className="px-3 py-1 bg-green-600 text-white text-sm rounded"
                  >
                    CSV
                  </button>
                  <button
                    onClick={() => handleExportReport(report.id, 'excel')}
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded"
                  >
                    Excel
                  </button>
                </div>
                
                <div className="text-xs text-gray-500 mt-2">
                  Criado em: {new Date(report.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
```

### Hooks Especializados

```tsx
import { useAnalytics, useAnalyticsDashboard } from '@/modules/Analytics/hooks';

// Hook principal (orquestrador)
const { dashboard, filters, realTime, reports } = useAnalytics();

// Hook específico para dashboard
const { dashboardData, loadDashboardData, updateDashboard } = useAnalyticsDashboard();

// Hook para filtros
const { filters, applyFilters, clearFilters } = useAnalyticsFilters();

// Hook para tempo real
const { realTimeEnabled, enableRealTime, disableRealTime } = useAnalyticsRealTime();

// Hook para relatórios
const { reports, createReport, exportReport } = useAnalyticsReports();
```

### Componentes

```tsx
import { 
  AnalyticsDashboard, 
  AnalyticsFilters, 
  AnalyticsMetrics 
} from '@/modules/Analytics/components';

// Dashboard completo
<AnalyticsDashboard />

// Filtros
<AnalyticsFilters 
  filters={filters}
  onFiltersChange={handleFiltersChange}
/>

// Métricas
<AnalyticsMetrics 
  data={metrics}
  loading={loading}
/>
```

## 🔧 Configuração

### Variáveis de Ambiente

```env
# Google Analytics
GOOGLE_ANALYTICS_CLIENT_ID=your_client_id
GOOGLE_ANALYTICS_CLIENT_SECRET=your_client_secret

# Facebook Analytics
FACEBOOK_APP_ID=your_app_id
FACEBOOK_APP_SECRET=your_app_secret

# API
ANALYTICS_API_URL=http://localhost:8000/api
ANALYTICS_WS_URL=ws://localhost:8000/ws
```

### Configuração do Store

```tsx
import { useAnalyticsStore } from '@/modules/Analytics/hooks';

// Configuração personalizada
const config = {
  real_time_enabled: true,
  auto_refresh: true,
  refresh_interval: 30000,
  default_period: '30days',
  default_report_type: 'overview',
  notifications_enabled: true,
  export_format: 'csv',
  theme: 'auto'
};

// Aplicar configuração
useAnalyticsStore.getState().updateConfig(config);
```

## 📊 Tipos de Dados

### Métricas Principais

```typescript
interface AnalyticsMetric {
  id: string;
  name: string;
  type: 'page_views' | 'unique_visitors' | 'bounce_rate' | 'conversion_rate';
  value: number;
  previous_value?: number;
  change_percentage?: number;
  trend: 'up' | 'down' | 'stable';
  unit: string;
  timestamp: string;
}
```

### Filtros

```typescript
interface AnalyticsFilters {
  date_range: 'today' | 'yesterday' | '7days' | '30days' | '90days' | 'custom';
  report_type: 'overview' | 'traffic' | 'conversions' | 'audience';
  start_date?: string;
  end_date?: string;
  metrics?: string[];
  devices?: string[];
  traffic_sources?: string[];
  custom_filters?: Record<string, any>;
}
```

### Relatórios

```typescript
interface AnalyticsReport {
  id: string;
  name: string;
  type: string;
  description?: string;
  filters: AnalyticsFilters;
  data: any;
  created_at: string;
  updated_at: string;
  created_by: string;
  is_public: boolean;
}
```

## 🧪 Testes

### Executar Testes

```bash
# Testes unitários
npm test

# Testes de integração
npm run test:integration

# Cobertura de testes
npm run test:coverage
```

### Estrutura de Testes

```typescript
// Teste de hook
import { renderHook } from '@testing-library/react';
import { useAnalytics } from '../hooks/useAnalytics';

test('should initialize with default values', () => {
  const { result } = renderHook(() => useAnalytics());
  
  expect(result.current.loading).toBe(false);
  expect(result.current.error).toBeNull();
});

// Teste de componente
import { render, screen } from '@testing-library/react';
import { AnalyticsDashboard } from '../components/AnalyticsDashboard';

test('should render dashboard', () => {
  render(<AnalyticsDashboard />);
  
  expect(screen.getByText('Analytics Dashboard')).toBeInTheDocument();
});
```

## 🔌 Integrações

### Google Analytics

```tsx
import { useGoogleAnalytics } from '@/modules/Analytics/hooks';

const { 
  isConnected, 
  connect, 
  disconnect, 
  getData 
} = useGoogleAnalytics();

// Conectar
await connect({
  property_id: 'UA-123456789-1',
  view_id: '123456789'
});

// Obter dados
const data = await getData('page_views', '30days');
```

### Facebook Analytics

```tsx
import { useFacebookAnalytics } from '@/modules/Analytics/hooks';

const { 
  isConnected, 
  connect, 
  getInsights 
} = useFacebookAnalytics();

// Conectar
await connect({
  app_id: '123456789',
  access_token: 'your_token'
});

// Obter insights
const insights = await getInsights('page_insights');
```

## 📈 Performance

### Otimizações Implementadas

- **Lazy Loading**: Componentes carregados sob demanda
- **Memoização**: React.memo, useMemo, useCallback
- **Cache Inteligente**: Cache com TTL configurável
- **Debouncing**: Filtros com debounce para evitar requisições excessivas
- **Virtualização**: Listas grandes com virtualização

### Métricas de Performance

- **Tempo de Carregamento**: < 2 segundos
- **Bundle Size**: < 500KB gzipped
- **Memory Usage**: < 50MB
- **Cache Hit Rate**: > 80%

## 🚨 Tratamento de Erros

### Error Boundaries

```tsx
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';

<ErrorBoundary>
  <AnalyticsDashboard />
</ErrorBoundary>
```

### Tratamento de Erros nos Hooks

```tsx
const { error, clearError } = useAnalytics();

if (error) {
  return (
    <ErrorState
      title="Erro ao carregar analytics"
      description={error}
      onRetry={clearError}
    />
  );
}
```

### Logs e Monitoramento

```tsx
// Logs automáticos
console.log('Analytics error:', error);

// Métricas de erro
analytics.track('analytics_error', {
  error_type: 'network',
  error_message: error.message,
  timestamp: new Date().toISOString()
});
```

## 🔒 Segurança

### Validação de Dados

```typescript
import { validateAnalyticsFilters } from '@/modules/Analytics/utils';

const validation = validateAnalyticsFilters(filters);
if (!validation.isValid) {
  throw new Error(`Filtros inválidos: ${validation.errors.join(', ')}`);
}
```

### Sanitização

```typescript
import { sanitizeInput } from '@/modules/Analytics/utils';

const sanitizedInput = sanitizeInput(userInput);
```

### Autenticação

```tsx
// Verificação de permissões
const { user } = useAuth();
if (!user?.permissions?.includes('analytics:read')) {
  return <UnauthorizedPage />;
}
```

## 📚 API Reference

### Hooks

#### useAnalytics()
Hook principal que orquestra todos os outros hooks.

**Retorna:**
- `dashboard`: Hook do dashboard
- `filters`: Hook dos filtros
- `realTime`: Hook do tempo real
- `reports`: Hook dos relatórios
- `loading`: Estado de carregamento
- `error`: Estado de erro

#### useAnalyticsDashboard()
Hook especializado para o dashboard.

**Métodos:**
- `loadDashboardData()`: Carrega dados do dashboard
- `updateDashboard()`: Atualiza dashboard
- `exportDashboardData(format)`: Exporta dados

#### useAnalyticsFilters()
Hook especializado para filtros.

**Métodos:**
- `applyFilters(filters)`: Aplica filtros
- `clearFilters()`: Limpa filtros
- `updatePeriod(period)`: Atualiza período

#### useAnalyticsRealTime()
Hook especializado para tempo real.

**Métodos:**
- `enableRealTime()`: Habilita tempo real
- `disableRealTime()`: Desabilita tempo real
- `toggleRealTime()`: Alterna tempo real

#### useAnalyticsReports()
Hook especializado para relatórios.

**Métodos:**
- `createReport(data)`: Cria relatório
- `editReport(id, data)`: Edita relatório
- `deleteReport(id)`: Exclui relatório
- `exportReport(id, format)`: Exporta relatório

### Componentes

#### AnalyticsDashboard
Componente principal do dashboard.

**Props:**
- `className?: string`: Classes CSS adicionais

#### AnalyticsFilters
Componente de filtros.

**Props:**
- `filters: AnalyticsFilters`: Filtros atuais
- `onFiltersChange: (filters) => void`: Callback de mudança

#### AnalyticsMetrics
Componente de métricas.

**Props:**
- `data?: AnalyticsMetric[]`: Dados das métricas
- `loading?: boolean`: Estado de carregamento

### Utilitários

#### formatNumber(value, options)
Formata números para exibição.

**Parâmetros:**
- `value: number`: Valor a ser formatado
- `options?: { decimals?, compact?, currency? }`: Opções de formatação

#### formatDate(date, options)
Formata datas para exibição.

**Parâmetros:**
- `date: string | Date`: Data a ser formatada
- `options?: { includeTime?, relative? }`: Opções de formatação

#### validateAnalyticsFilters(filters)
Valida filtros de analytics.

**Parâmetros:**
- `filters: AnalyticsFilters`: Filtros a serem validados

**Retorna:**
- `{ isValid: boolean, errors: string[] }`: Resultado da validação

## 🤝 Contribuição

### Padrões de Código

1. **TypeScript**: Sempre use tipagem estática
2. **ESLint**: Siga as regras configuradas
3. **Prettier**: Use formatação consistente
4. **Testes**: Cobertura mínima de 80%
5. **Documentação**: Documente funções públicas

### Processo de Contribuição

1. Fork do repositório
2. Crie uma branch para sua feature
3. Implemente com testes
4. Execute linting e testes
5. Abra um Pull Request

### Estrutura de Commits

```
feat: adiciona nova funcionalidade
fix: corrige bug
docs: atualiza documentação
test: adiciona testes
refactor: refatora código
perf: melhora performance
```

## 📝 Changelog

### v2.0.0 (2024-01-15)
- ✅ Refatoração completa da arquitetura
- ✅ Implementação de hooks especializados
- ✅ Store Zustand com TypeScript
- ✅ Componentes modulares
- ✅ Testes unitários e de integração
- ✅ Documentação completa

### v1.0.0 (2023-12-01)
- ✅ Versão inicial
- ✅ Dashboard básico
- ✅ Integração com Google Analytics
- ✅ Relatórios simples

## 📞 Suporte

### Documentação
- [Guia de Início Rápido](./docs/quick-start.md)
- [API Reference](./docs/api-reference.md)
- [Exemplos](./docs/examples.md)

### Comunidade
- [GitHub Issues](https://github.com/xwin-dash/analytics/issues)
- [Discord](https://discord.gg/xwin-dash)
- [Email](mailto:support@xwin-dash.com)

### Recursos Adicionais
- [Blog](https://blog.xwin-dash.com)
- [Tutoriais](https://tutorials.xwin-dash.com)
- [Vídeos](https://youtube.com/xwin-dash)

---

**Desenvolvido com ❤️ pela equipe xWin Dash**

*Última atualização: 15 de Janeiro de 2024*