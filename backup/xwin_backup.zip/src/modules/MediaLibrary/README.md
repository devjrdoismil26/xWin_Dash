# Módulo MediaLibrary - xWin Dash

## Visão Geral

O módulo **MediaLibrary** foi completamente modernizado para oferecer uma biblioteca de mídia completa e intuitiva, com funcionalidades avançadas de upload, organização, busca e gerenciamento de arquivos multimídia.

## Funcionalidades

### 📁 **Gerenciamento de Arquivos**
- **Upload Avançado**: Drag & drop, múltiplos arquivos, progresso em tempo real
- **Organização**: Sistema de pastas hierárquicas
- **Tipos Suportados**: Imagens, vídeos, áudio, documentos, outros
- **Validação**: Verificação de tipo e tamanho de arquivos

### 🔍 **Busca e Filtros**
- **Busca Inteligente**: Por nome, tipo, data, tamanho
- **Filtros Avançados**: Por tipo de arquivo, período, tags
- **Ordenação**: Por nome, data, tamanho, tipo
- **Visualizações**: Modo grid e lista

### 📊 **Estatísticas e Monitoramento**
- **Métricas Detalhadas**: Contadores por tipo de arquivo
- **Uso de Armazenamento**: Visualização de espaço usado/limite
- **Progresso de Upload**: Indicadores visuais em tempo real
- **Histórico**: Log de atividades e uploads

### 🎛️ **Operações em Lote**
- **Seleção Múltipla**: Selecionar vários arquivos
- **Ações em Massa**: Excluir, mover, download
- **Organização**: Mover arquivos entre pastas
- **Exportação**: Download de múltiplos arquivos

## Arquitetura

### Hooks Customizados

#### `useMediaLibrary`
Hook principal para gerenciamento da biblioteca:
```typescript
const {
  media,
  folders,
  stats,
  loading,
  error,
  currentFolder,
  viewMode,
  sortBy,
  sortOrder,
  filters,
  selectedMedia,
  fetchMedia,
  uploadMedia,
  createFolder,
  updateMedia,
  deleteMedia,
  searchMedia,
  refreshData,
  getMediaType,
  formatFileSize,
  getFileIcon,
} = useMediaLibrary();
```

#### `useMediaUpload`
Hook especializado para upload de arquivos:
```typescript
const {
  uploads,
  isUploading,
  dragActive,
  fileInputRef,
  uploadFiles,
  clearUploads,
  openFileDialog,
  handleFileSelect,
  handleDragEnter,
  handleDragLeave,
  handleDragOver,
  handleDrop,
  getUploadStatus,
  getTotalProgress,
} = useMediaUpload();
```

### Componentes

#### `MediaLibrary/index.tsx`
Componente principal modernizado:
- Interface Glassmorphism
- Sistema de upload drag & drop
- Navegação por pastas
- Filtros e busca avançados
- Operações em lote
- Modais para upload e criação de pastas

## Integração com Backend

### API Endpoints
- `GET /api/v1/media` - Listar arquivos de mídia
- `POST /api/v1/media/upload` - Upload de arquivos
- `GET /api/v1/media/{id}` - Obter arquivo específico
- `PUT /api/v1/media/{id}` - Atualizar arquivo
- `DELETE /api/v1/media/{id}` - Excluir arquivo
- `GET /api/v1/media/folders` - Listar pastas
- `POST /api/v1/media/folders` - Criar pasta
- `PUT /api/v1/media/folders/{id}` - Atualizar pasta
- `DELETE /api/v1/media/folders/{id}` - Excluir pasta
- `GET /api/v1/media/stats` - Estatísticas da biblioteca
- `GET /api/v1/media/search` - Buscar arquivos

### Estruturas de Dados

#### MediaFile
```typescript
interface MediaFile {
  id: number;
  name: string;
  file_name: string;
  mime_type: string;
  path: string;
  size: number;
  folder_id?: number;
  user_id: number;
  created_at: string;
  updated_at: string;
  url?: string;
  thumbnail_url?: string;
  tags?: string[];
  alt_text?: string;
  description?: string;
}
```

#### MediaFolder
```typescript
interface MediaFolder {
  id: number;
  name: string;
  parent_id?: number;
  user_id: number;
  created_at: string;
  updated_at: string;
  media_count?: number;
  children?: MediaFolder[];
}
```

#### MediaStats
```typescript
interface MediaStats {
  total_files: number;
  total_folders: number;
  total_size: number;
  files_by_type: {
    images: number;
    videos: number;
    documents: number;
    audio: number;
    others: number;
  };
  storage_usage: {
    used: number;
    limit: number;
    percentage: number;
  };
}
```

## Design System

### Glassmorphism
- **Backgrounds**: `backdrop-blur-xl bg-white/10`
- **Borders**: `border-white/20`
- **Hover Effects**: `hover:bg-white/20`
- **Shadows**: `hover:shadow-2xl hover:shadow-blue-500/10`

### Cores e Temas
- **Azul**: Arquivos gerais e ações principais
- **Verde**: Imagens
- **Roxo**: Vídeos
- **Laranja**: Documentos
- **Rosa**: Áudio
- **Vermelho**: Ações de exclusão

### Componentes UI
- **Cards**: Com efeitos de hover e transições
- **Modais**: Para upload e criação de pastas
- **Progress Bars**: Para uploads em progresso
- **Badges**: Para tipos de arquivo
- **Breadcrumbs**: Para navegação de pastas

## Funcionalidades Avançadas

### Sistema de Upload
- **Drag & Drop**: Arrastar arquivos para upload
- **Validação**: Verificação de tipo e tamanho
- **Progresso**: Indicadores visuais em tempo real
- **Múltiplos Arquivos**: Upload simultâneo
- **Retry**: Tentar novamente em caso de erro

### Organização de Arquivos
- **Pastas Hierárquicas**: Estrutura de pastas aninhadas
- **Navegação**: Breadcrumbs para navegação
- **Busca**: Busca em tempo real
- **Filtros**: Por tipo, data, tamanho
- **Ordenação**: Múltiplos critérios

### Operações em Lote
- **Seleção Múltipla**: Selecionar vários arquivos
- **Ações em Massa**: Excluir, mover, download
- **Interface Intuitiva**: Barra de ações contextual
- **Confirmação**: Confirmação para ações destrutivas

### Estatísticas e Monitoramento
- **Métricas Visuais**: Cards com estatísticas
- **Uso de Armazenamento**: Barra de progresso
- **Contadores**: Por tipo de arquivo
- **Tendências**: Análise de uso

## Performance

### Otimizações
- **Lazy Loading**: Carregamento sob demanda
- **Debouncing**: Busca com debounce
- **Caching**: Cache de dados
- **Virtualization**: Para listas grandes

### Validações
- **Tipos Permitidos**: Validação de MIME types
- **Tamanho Máximo**: Limite de 100MB por arquivo
- **Extensões**: Verificação de extensões
- **Segurança**: Validação de uploads

## Responsividade

### Breakpoints
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px
- **Large**: > 1440px

### Adaptações
- **Grid Responsivo**: Colunas adaptáveis
- **Touch Friendly**: Botões otimizados para touch
- **Navegação Mobile**: Menu colapsável
- **Upload Mobile**: Interface adaptada

## Roadmap

### Próximas Funcionalidades
- [ ] **CDN Integration**: Integração com CDN
- [ ] **Image Processing**: Redimensionamento automático
- [ ] **Video Thumbnails**: Geração de thumbnails
- [ ] **Metadata Extraction**: Extração de metadados
- [ ] **AI Tagging**: Tagging automático com IA

### Melhorias Planejadas
- [ ] **Versioning**: Controle de versões
- [ ] **Sharing**: Compartilhamento de arquivos
- [ ] **Collaboration**: Colaboração em tempo real
- [ ] **Backup**: Sistema de backup
- [ ] **Analytics**: Analytics detalhados

## Uso

### Hook Principal - useMediaLibrary
```typescript
import { useMediaLibrary } from '../hooks/useMediaLibrary';

const MediaLibraryComponent = () => {
  const {
    media,
    folders,
    stats,
    isLoading,
    error,
    currentFolder,
    selectedMedia,
    loadMedia,
    uploadFiles,
    createFolder,
    updateMedia,
    deleteMedia,
    searchMedia,
    refreshData
  } = useMediaLibrary();

  // Carregar mídia inicial
  useEffect(() => {
    loadMedia();
  }, []);

  return (
    <div>
      {/* Interface da biblioteca de mídia */}
    </div>
  );
};
```

### Hook Especializado - useMediaCore
```typescript
import { useMediaCore } from '../hooks/useMediaCore';

const MediaCoreComponent = () => {
  const {
    media,
    isLoading,
    uploadFiles,
    updateMediaMetadata,
    deleteMediaFile,
    getMediaInfo,
    getMediaByType
  } = useMediaCore();

  const handleUpload = async (files: File[]) => {
    await uploadFiles(files, currentFolder);
  };

  const handleUpdate = async (mediaId: string) => {
    await updateMediaMetadata(mediaId, {
      name: 'Novo nome',
      description: 'Nova descrição'
    });
  };

  return (
    <div>
      {/* Interface com funcionalidades básicas */}
    </div>
  );
};
```

### Hook Especializado - useMediaManager
```typescript
import { useMediaManager } from '../hooks/useMediaManager';

const MediaManagerComponent = () => {
  const {
    folders,
    selectedMedia,
    createNewFolder,
    renameFolder,
    moveFolder,
    deleteFolderAndContents,
    moveMediaToFolder,
    selectMedia,
    selectAllMedia,
    clearSelection,
    navigateToFolder,
    getFolderTree,
    getCurrentFolderPath
  } = useMediaManager();

  const handleCreateFolder = async () => {
    await createNewFolder('Nova Pasta', currentFolder, 'Descrição da pasta');
  };

  const handleMoveFiles = async () => {
    await moveMediaToFolder(selectedMedia, 'target-folder-id');
  };

  return (
    <div>
      {/* Interface de gerenciamento */}
    </div>
  );
};
```

### Hook Especializado - useMediaAnalytics
```typescript
import { useMediaAnalytics } from '../hooks/useMediaAnalytics';

const MediaAnalyticsComponent = () => {
  const {
    stats,
    analyticsData,
    isLoadingAnalytics,
    generateUsageReport,
    updateDateRange,
    exportAnalyticsData,
    usageByType,
    folderStats,
    growthTrends
  } = useMediaAnalytics();

  const handleGenerateReport = async () => {
    const report = await generateUsageReport();
    console.log('Relatório gerado:', report);
  };

  const handleExport = () => {
    exportAnalyticsData('json');
  };

  return (
    <div>
      {/* Interface de analytics */}
    </div>
  );
};
```

### Hook Especializado - useMediaAI
```typescript
import { useMediaAI } from '../hooks/useMediaAI';

const MediaAIComponent = () => {
  const {
    isAnalyzing,
    isGeneratingTags,
    analyzeContent,
    generateTags,
    findSimilarMedia,
    batchProcessMedia,
    optimizeMedia,
    suggestOrganization,
    getAiStats
  } = useMediaAI();

  const handleAnalyze = async (mediaId: string) => {
    const analysis = await analyzeContent(mediaId);
    console.log('Análise concluída:', analysis);
  };

  const handleGenerateTags = async (mediaId: string) => {
    const tags = await generateTags(mediaId);
    console.log('Tags geradas:', tags);
  };

  const handleBatchProcess = async (mediaIds: string[]) => {
    await batchProcessMedia(mediaIds, ['analyze', 'tag']);
  };

  return (
    <div>
      {/* Interface de IA */}
    </div>
  );
};
```

### Componente de Filtros
```typescript
import MediaLibraryFilters from '../components/MediaLibraryFilters';

const MediaLibraryWithFilters = () => {
  const handleFiltersChange = (filters: MediaFilters) => {
    console.log('Filtros aplicados:', filters);
    // Aplicar filtros na busca
  };

  return (
    <div>
      <MediaLibraryFilters onFiltersChange={handleFiltersChange} />
      {/* Resto da interface */}
    </div>
  );
};
```

### Upload de Arquivos
1. Clique em **Upload** ou arraste arquivos
2. Selecione os arquivos desejados
3. Acompanhe o progresso do upload
4. Arquivos aparecem na biblioteca

### Organização
1. Crie pastas com **Nova Pasta**
2. Navegue pelas pastas usando breadcrumbs
3. Mova arquivos entre pastas
4. Use filtros para encontrar arquivos

### Busca e Filtros
1. Use a barra de busca para encontrar arquivos
2. Aplique filtros por tipo, data, tamanho
3. Ordene por diferentes critérios
4. Alterne entre visualizações grid/lista

### Operações em Lote
1. Selecione múltiplos arquivos
2. Use a barra de ações em lote
3. Execute ações como excluir, mover, download
4. Confirme ações destrutivas

### Funcionalidades de IA
1. Analise conteúdo automaticamente
2. Gere tags inteligentes
3. Encontre arquivos similares
4. Otimize arquivos automaticamente
5. Receba sugestões de organização

## Contribuição

Para contribuir com o módulo MediaLibrary:

1. Siga os padrões de código estabelecidos
2. Mantenha a consistência visual com Glassmorphism
3. Teste todas as funcionalidades antes de submeter
4. Documente novas funcionalidades no README
5. Atualize os tipos TypeScript quando necessário

## Suporte

Para suporte técnico ou dúvidas sobre o módulo:
- Consulte a documentação da API
- Verifique os logs do console para erros
- Teste a conectividade com o backend
- Valide as permissões de usuário
- Verifique o espaço disponível para upload