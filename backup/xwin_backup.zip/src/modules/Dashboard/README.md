# 📊 Dashboard Module - xWin Dash

## 🎯 Visão Geral

O módulo Dashboard é o **centro de controle visual** da aplicação xWin Dash. Ele só é acessível quando há um **projeto ativo selecionado** e fornece uma visão geral das métricas e performance do projeto.

## 🏗️ Estrutura Organizada

```
Dashboard/
├── DashboardMain.tsx              # 🎯 Componente principal integrado
├── components/                    # Componentes do dashboard
│   ├── DashboardMetricsCards.tsx  # Cards de métricas
│   ├── RecentActivities.tsx       # Atividades recentes
│   ├── ProjectsStatsSummary.tsx   # Resumo de projetos
│   ├── widgets/                   # Widgets específicos
│   │   ├── ADSPerformanceWidget.tsx
│   │   ├── AIProcessingWidget.tsx
│   │   ├── AnalyticsOverviewWidget.tsx
│   │   ├── AuraConversationsWidget.tsx
│   │   ├── CalendarIntegrationWidget.tsx
│   │   ├── EmailMarketingWidget.tsx
│   │   ├── MediaLibraryWidget.tsx
│   │   ├── ProductsPerformanceWidget.tsx
│   │   ├── SocialBufferWidget.tsx
│   │   ├── UniverseWidget.tsx
│   │   └── WorkflowsStatusWidget.tsx
│   └── ...                       # Outros componentes
├── hooks/                        # Hooks do módulo
│   ├── useDashboard.ts           # Hook principal
│   ├── useDashboardCore.ts       # Hook core
│   ├── useDashboardMetrics.ts    # Hook para métricas
│   ├── useDashboardWidgets.ts    # Hook para widgets
│   └── useDashboardAdvanced.ts   # Hook avançado
├── services/                     # Serviços
│   └── dashboardService.ts       # Serviço principal
├── types/                        # Tipos TypeScript
│   └── dashboardTypes.ts         # Tipos unificados
├── utils/                        # Utilitários
└── index.tsx                     # Exports organizados
```

## 🔄 Fluxo de Acesso

### 1. **Projeto Selecionado** → **Dashboard**
- Usuário deve ter um projeto ativo selecionado
- Dashboard só aparece com projeto na sessão
- Métricas filtradas por projeto (quando aplicável)

### 2. **Dashboard Integrado**
- Mostra informações do projeto atual
- Métricas globais da aplicação
- Atividades recentes
- Ações rápidas baseadas no modo do projeto

### 3. **Acesso ao Universe**
- Se projeto é modo Universe, botão especial aparece
- Integração direta com módulo Universe

## 🎨 Componente Principal

### DashboardMain.tsx
- **Função**: Interface principal do dashboard
- **Recursos**: 
  - Métricas em cards visuais
  - Atividades recentes
  - Ações rápidas
  - Integração com projeto atual
  - Acesso ao Universe (se aplicável)

## 🔧 Hooks Principais

### useDashboard
- Hook principal que expõe funcionalidades essenciais
- Interface simplificada para componentes
- Integração com métricas e widgets

### useDashboardCore
- Hook core com funcionalidades básicas
- Gerenciamento de estado
- Operações fundamentais

### useDashboardMetrics
- Hook específico para métricas
- Cálculos e formatação
- Tendências e comparações

### useDashboardWidgets
- Hook para gerenciamento de widgets
- Layout e posicionamento
- Dados e configurações

## 🎯 Tipos Principais

```typescript
interface DashboardData {
  metrics: {
    total_leads: number;
    total_users: number;
    total_projects: number;
    active_projects: number;
    total_campaigns: number;
    total_revenue: number;
    conversion_rate: number;
    leads_growth: number;
    users_growth: number;
    projects_growth: number;
    campaigns_growth: number;
    revenue_growth: number;
  };
  recent_activities: RecentActivity[];
  top_leads: TopLead[];
  recent_projects: RecentProject[];
  stats: DashboardStats;
}
```

## 🚀 Funcionalidades

### ✅ Implementadas
- [x] Dashboard integrado com projetos
- [x] Métricas visuais em cards
- [x] Atividades recentes
- [x] Ações rápidas
- [x] Integração com Universe
- [x] Responsividade completa
- [x] Tema dark/light

### 🔄 Em Desenvolvimento
- [ ] Widgets personalizáveis
- [ ] Métricas filtradas por projeto
- [ ] Exportação de dados
- [ ] Alertas e notificações
- [ ] Dashboard compartilhado

## 🔗 Integração com Backend

- **Rota**: `/dashboard` (com middleware `project.selected`)
- **Controller**: `DashboardController::renderDashboard()`
- **Dados**: Métricas reais do banco de dados
- **Projeto**: Informações do projeto atual na sessão

## 📝 Notas Importantes

1. **Acesso condicional**: Só funciona com projeto selecionado
2. **Integração com projetos**: Mostra informações do projeto atual
3. **Métricas reais**: Dados vindos do banco de dados
4. **Universe integrado**: Acesso direto se projeto for modo Universe
5. **Responsivo**: Funciona em todos os dispositivos

## 🎨 Design

- **Visual moderno**: Cards com backdrop blur
- **Cores consistentes**: Sistema de cores unificado
- **Animações suaves**: Transições e hover effects
- **Ícones intuitivos**: Lucide React icons
- **Tipografia clara**: Hierarquia visual bem definida

---

**Última atualização**: Setembro 2024  
**Status**: ✅ Dashboard integrado e funcional