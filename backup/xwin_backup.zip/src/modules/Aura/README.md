# Módulo Aura - Sistema de Comunicação Inteligente

O módulo Aura é um sistema completo de comunicação inteligente que permite gerenciar conexões, fluxos automatizados, chats e analytics em tempo real.

## 🏗️ Arquitetura Modular

O módulo Aura segue uma **arquitetura modular bem estruturada** com submódulos especializados:

```
Frontend/src/modules/Aura/
├── AuraCore/                    # 🎯 Módulo principal
│   ├── components/
│   │   ├── AuraDashboard.tsx   # Dashboard principal
│   │   ├── AuraHeader.tsx      # Cabeçalho
│   │   └── AuraStats.tsx       # Estatísticas
│   ├── hooks/
│   │   ├── useAuraCore.ts      # Hook principal
│   │   └── useAuraStore.ts     # Store Zustand
│   ├── services/
│   ├── types/
│   └── utils/
│
├── AuraFlows/                   # 🔄 Sistema de fluxos
│   ├── components/
│   ├── hooks/
│   │   └── useAuraFlows.ts     # Hook especializado
│   ├── services/
│   ├── types/
│   └── utils/
│
├── AuraChats/                   # 💬 Sistema de chats
│   ├── components/
│   ├── hooks/
│   │   └── useAuraChats.ts     # Hook especializado
│   ├── services/
│   ├── types/
│   └── utils/
│
├── AuraConnections/             # 🔗 Sistema de conexões
│   ├── components/
│   ├── hooks/
│   │   └── useAuraConnections.ts # Hook especializado
│   ├── services/
│   ├── types/
│   └── utils/
│
├── Flows/                       # 🎨 Componentes específicos de fluxos
│   ├── components/
│   │   ├── FlowBuilder.tsx     # Editor visual de fluxos
│   │   ├── ModernFlowBuilder.tsx # Editor moderno
│   │   ├── NodePanel.tsx       # Painel de nós
│   │   └── nodes/              # 15+ tipos de nós
│   │       ├── SendMessageNode.tsx
│   │       ├── ConditionKeywordNode.tsx
│   │       ├── DelayNode.tsx
│   │       ├── WebhookNode.tsx
│   │       └── ... (muitos outros)
│
├── Chats/                       # 💬 Componentes específicos de chats
│   ├── components/
│   │   ├── AuraChatList.tsx    # Lista de chats
│   │   ├── AuraMessageBubble.tsx # Bolha de mensagem
│   │   ├── AuraChatFilters.tsx # Filtros de chat
│   │   └── AssignChatModal.tsx # Modal de atribuição
│
├── Connections/                 # 🔗 Componentes específicos de conexões
│   ├── components/
│   │   ├── ConnectionForm.tsx  # Formulário de conexão
│   │   ├── ConnectionTable.tsx # Tabela de conexões
│   │   ├── QRCodeDisplayModal.tsx # Modal de QR Code
│   │   └── VerificationModal.tsx # Modal de verificação
│
├── Stats/                      # 📊 Componentes de analytics
│   ├── components/
│   │   ├── AuraStatsCards.tsx  # Cards de estatísticas
│   │   ├── AuraStatsChart.tsx  # Gráficos
│   │   └── AuraStatsFilters.tsx # Filtros de stats
│
├── components/                 # 🧩 Componentes gerais
│   ├── AuraAnalyticsOverview.tsx
│   ├── AuraBenchmarks.tsx
│   ├── AuraDashboards.tsx
│   ├── AuraAlerts.tsx
│   ├── AuraReports.tsx
│   ├── AuraIntegrationTest.tsx
│   └── ... (outros componentes)
│
├── hooks/                      # 🎣 Hooks principais
│   ├── useAura.ts             # Hook principal
│   ├── useAuraStore.ts        # Store principal
│   ├── useAuraAdvanced.ts     # Hooks avançados
│   └── ... (outros hooks)
│
├── services/                   # 🔧 Serviços de API
│   ├── auraService.ts         # Serviço principal
│   ├── AuraAnalyticsService.ts
│   ├── AuraChatService.ts
│   ├── AuraConnectionService.ts
│   └── AuraFlowService.ts
│
├── types/                      # 📝 Tipos TypeScript
│   └── auraTypes.ts           # Tipos principais
│
├── utils/                      # 🛠️ Utilitários
│   ├── auraFormatters.ts      # Formatadores
│   ├── auraHelpers.ts         # Helpers
│   └── auraValidators.ts      # Validadores
│
├── pages/                      # 📄 Páginas
│   ├── ChatsIndex.tsx
│   ├── ConnectionsIndex.tsx
│   ├── FlowsIndex.tsx
│   ├── StatsIndex.tsx
│   └── ... (outras páginas)
│
└── index.tsx                   # 🚪 Ponto de entrada
```

## 🚀 Funcionalidades Principais

### 🎯 AuraCore
- **Dashboard Principal**: Visão geral com métricas e status
- **Estatísticas**: Cards com dados em tempo real
- **Ações Rápidas**: Acesso rápido às funcionalidades
- **Navegação**: Sistema de navegação entre módulos

### 🔄 AuraFlows
- **Editor Visual**: Canvas interativo para criar fluxos
- **15+ Tipos de Nós**: Mensagem, Condição, Delay, Webhook, etc.
- **Templates**: Sistema de templates para fluxos
- **Execução**: Monitoramento de execuções em tempo real
- **Validação**: Validação automática de fluxos

### 💬 AuraChats
- **Lista de Chats**: Interface completa de conversas
- **Mensagens**: Suporte a múltiplos tipos de mídia
- **Filtros**: Sistema avançado de filtros
- **Atribuição**: Sistema de atribuição de chats
- **Status**: Controle de status das conversas

### 🔗 AuraConnections
- **Multi-plataforma**: WhatsApp, Telegram, Instagram, Facebook, Website, Email
- **Configuração**: Formulários específicos para cada plataforma
- **Teste**: Sistema de teste de conexões
- **Monitoramento**: Status e saúde das conexões
- **QR Code**: Integração com QR Code para WhatsApp

### 📊 Analytics
- **Métricas**: Dados detalhados de performance
- **Relatórios**: Sistema de relatórios personalizados
- **Dashboards**: Dashboards configuráveis
- **Alertas**: Sistema de alertas inteligentes
- **Benchmarks**: Comparação com benchmarks da indústria

## 📖 Uso

### Importação dos Módulos

```typescript
// Importar módulo completo
import { AuraCore } from '@/modules/Aura/AuraCore';
import { AuraFlows } from '@/modules/Aura/AuraFlows';
import { AuraChats } from '@/modules/Aura/AuraChats';
import { AuraConnections } from '@/modules/Aura/AuraConnections';

// Importar hooks especializados
import { useAuraCore } from '@/modules/Aura/AuraCore/hooks';
import { useAuraFlows } from '@/modules/Aura/AuraFlows/hooks';
import { useAuraChats } from '@/modules/Aura/AuraChats/hooks';
import { useAuraConnections } from '@/modules/Aura/AuraConnections/hooks';

// Importar componentes específicos
import { FlowBuilder } from '@/modules/Aura/Flows/components/FlowBuilder';
import { AuraChatList } from '@/modules/Aura/Chats/components/AuraChatList';
import { ConnectionForm } from '@/modules/Aura/Connections/components/ConnectionForm';
```

### Uso dos Hooks Especializados

#### useAuraCore
```typescript
import { useAuraCore } from '@/modules/Aura/AuraCore/hooks';

function DashboardComponent() {
  const {
    loading,
    error,
    stats,
    modules,
    quick_actions,
    refreshAllData,
    getDashboardStatus,
    hasData
  } = useAuraCore();

  if (loading && !hasData()) {
    return <LoadingSpinner size="lg" />;
  }

  return (
    <div>
      <h1>Dashboard Aura</h1>
      <div>
        <p>Conexões: {stats?.total_connections || 0}</p>
        <p>Fluxos Ativos: {stats?.active_flows || 0}</p>
        <p>Mensagens Enviadas: {stats?.messages_sent || 0}</p>
      </div>
    </div>
  );
}
```

#### useAuraFlows
```typescript
import { useAuraFlows } from '@/modules/Aura/AuraFlows/hooks';

function FlowManager() {
  const {
    flows,
    executions,
    templates,
    loading,
    error,
    selectedFlow,
    fetchFlows,
    createFlow,
    updateFlow,
    deleteFlow,
    executeFlow,
    pauseFlow,
    resumeFlow,
    setSelectedFlow
  } = useAuraFlows();

  const handleCreateFlow = async () => {
    const newFlow = {
      name: 'Fluxo de Boas-vindas',
      description: 'Fluxo para novos usuários',
      status: 'active',
      trigger_type: 'message_received',
      trigger_config: { keyword: 'oi' },
      nodes: [],
      connections: [],
      variables: {},
      settings: {
        max_executions: 1000,
        timeout: 300,
        retry_attempts: 3,
        retry_delay: 5000,
        error_handling: 'stop',
        logging_enabled: true,
        notifications_enabled: true
      }
    };

    const result = await createFlow(newFlow);
    if (result.success) {
      console.log('Fluxo criado com sucesso!');
    }
  };

  return (
    <div>
      <h2>Fluxos ({flows.length})</h2>
      <button onClick={handleCreateFlow}>
        Novo Fluxo
      </button>
    </div>
  );
}
```

#### useAuraChats
```typescript
import { useAuraChats } from '@/modules/Aura/AuraChats/hooks';

function ChatManager() {
  const {
    chats,
    messages,
    contacts,
    selectedChat,
    loading,
    error,
    fetchChats,
    createChat,
    updateChat,
    deleteChat,
    sendMessage,
    fetchMessages,
    markAsRead,
    closeChat,
    archiveChat,
    setSelectedChat
  } = useAuraChats();

  const handleSendMessage = async (chatId: string) => {
    const result = await sendMessage(chatId, {
      direction: 'outbound',
      type: 'text',
      content: 'Olá! Como posso ajudar?',
      status: 'sent'
    });
    
    if (result.success) {
      console.log('Mensagem enviada com sucesso!');
    }
  };

  return (
    <div>
      <h2>Chats ({chats.length})</h2>
      <div>
        {chats.map(chat => (
          <div key={chat.id}>
            <h3>{chat.contact_name}</h3>
            <p>{chat.last_message?.content}</p>
            <button onClick={() => handleSendMessage(chat.id)}>
              Responder
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
```

#### useAuraConnections
```typescript
import { useAuraConnections } from '@/modules/Aura/AuraConnections/hooks';

function ConnectionManager() {
  const {
    connections,
    loading,
    error,
    selectedConnection,
    fetchConnections,
    createConnection,
    updateConnection,
    deleteConnection,
    testConnection,
    connectWhatsApp,
    disconnectWhatsApp,
    refreshConnection,
    setSelectedConnection
  } = useAuraConnections();

  const handleCreateConnection = async () => {
    const newConnection = {
      name: 'WhatsApp Business Principal',
      description: 'Conexão principal do WhatsApp Business',
      provider: 'whatsapp_business',
      type: 'webhook',
      status: 'connected',
      auth_type: 'token',
      config: {
        api_url: 'https://graph.facebook.com/v18.0',
        access_token: 'your-access-token',
        phone_number: '+5511999999999',
        business_account_id: '123456789'
      },
      webhook_url: 'https://api.example.com/webhook/whatsapp',
      webhook_secret: 'your-webhook-secret'
    };

    const result = await createConnection(newConnection);
    if (result.success) {
      console.log('Conexão criada com sucesso!');
    }
  };

  return (
    <div>
      <h2>Conexões ({connections.length})</h2>
      <button onClick={handleCreateConnection}>
        Nova Conexão
      </button>
    </div>
  );
}
```

### Uso dos Componentes Específicos

#### FlowBuilder
```typescript
import { FlowBuilder } from '@/modules/Aura/Flows/components/FlowBuilder';

function FlowBuilderPage() {
  return (
    <FlowBuilder />
  );
}
```

#### AuraChatList
```typescript
import { AuraChatList } from '@/modules/Aura/Chats/components/AuraChatList';

function ChatListPage() {
  const handleChatSelect = (chat) => {
    console.log('Chat selecionado:', chat);
  };

  return (
    <AuraChatList 
      onSelect={handleChatSelect}
      refreshTrigger={Date.now()}
    />
  );
}
```

#### ConnectionForm
```typescript
import { ConnectionForm } from '@/modules/Aura/Connections/components/ConnectionForm';

function ConnectionSetupPage() {
  const handleSubmit = (data) => {
    console.log('Dados da conexão:', data);
  };

  const handleSuccess = () => {
    console.log('Conexão criada com sucesso!');
  };

  return (
    <ConnectionForm 
      onSubmit={handleSubmit}
      onSuccess={handleSuccess}
    />
  );
}
```

## 🧪 Testes

### Estrutura de Testes

```
Frontend/src/modules/Aura/
├── AuraCore/tests/
│   ├── auraCore.test.ts
│   └── __mocks__/
│       └── auraCoreService.ts
├── AuraFlows/tests/
├── AuraChats/tests/
├── AuraConnections/tests/
└── tests/
```

### Executar Testes

```bash
# Testes do AuraCore
npm test -- --testPathPattern=AuraCore

# Testes de todos os módulos
npm test -- --testPathPattern=Aura

# Cobertura de testes
npm test -- --coverage --testPathPattern=Aura
```

## 🔧 Configuração

### Variáveis de Ambiente

```env
# Backend
AURA_API_URL=http://localhost:8000/api/aura
AURA_WEBSOCKET_URL=ws://localhost:8000/ws

# WhatsApp Business API
WHATSAPP_API_URL=https://graph.facebook.com/v18.0
WHATSAPP_ACCESS_TOKEN=your-access-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
WHATSAPP_WEBHOOK_VERIFY_TOKEN=your-verify-token

# Telegram Bot
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_WEBHOOK_URL=https://your-domain.com/webhook/telegram
```

### Configuração de Rotas

```php
// routes/api.php
Route::prefix('aura')->group(function () {
    Route::apiResource('connections', ConnectionController::class);
    Route::apiResource('flows', FlowController::class);
    Route::apiResource('chats', ChatController::class);
    Route::apiResource('messages', MessageController::class);
    Route::get('analytics/overview', [AnalyticsController::class, 'overview']);
    Route::get('webhooks', [WebhookController::class, 'index']);
});
```

## 📊 Performance

### Otimizações Implementadas

- **Lazy Loading**: Componentes pesados são carregados sob demanda
- **Memoização**: Hooks e componentes são memoizados quando apropriado
- **Debounce**: Inputs de busca têm debounce para evitar muitas requisições
- **Cache**: Dados são cacheados com TTL configurável
- **Virtualização**: Listas grandes usam virtualização para performance

### Métricas de Performance

- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Time to Interactive**: < 3.0s
- **Bundle Size**: < 500KB (gzipped)

## 🚀 Deploy

### Build de Produção

```bash
npm run build
```

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

Para suporte e dúvidas:

- 📧 Email: suporte@aura.com
- 💬 Discord: [Servidor da Comunidade](https://discord.gg/aura)
- 📖 Documentação: [docs.aura.com](https://docs.aura.com)
- 🐛 Issues: [GitHub Issues](https://github.com/aura/issues)