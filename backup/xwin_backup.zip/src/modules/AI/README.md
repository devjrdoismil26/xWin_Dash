# Módulo AI

## Visão Geral

O módulo **AI** é responsável por gerenciar todas as funcionalidades de inteligência artificial do sistema, incluindo geração de texto, imagem e vídeo, chat inteligente, analytics avançados e integração com múltiplos provedores de IA.

## Estrutura

```
AI/
├── index.tsx                    # Entry point principal (68 linhas)
├── types/                       # Definições de tipos TypeScript
│   ├── index.ts
│   ├── aiTypes.ts
│   ├── aiInterfaces.ts
│   ├── aiEnums.ts
│   └── aiProviders.ts
├── hooks/                       # Hooks customizados
│   ├── index.ts
│   ├── useAI.ts                # Hook principal orquestrador (218 linhas)
│   ├── useAIStore.ts           # Store Zustand com TypeScript
│   ├── useAIGeneration.ts      # Geração de conteúdo
│   ├── useAIProviders.ts       # Gerenciamento de provedores
│   ├── useAIHistory.ts         # Histórico de interações
│   └── useAIAnalytics.ts       # Analytics e métricas
├── services/                    # Camada de serviços
│   ├── index.ts
│   ├── aiService.ts            # Orquestrador principal
│   ├── aiProviderService.ts    # Gerenciamento de provedores
│   ├── aiGenerationService.ts  # Geração de conteúdo
│   └── aiAnalyticsService.ts   # Analytics e métricas
├── components/                  # Componentes React
│   ├── index.ts
│   ├── AIDashboard.tsx         # Dashboard base com variantes
│   ├── AdvancedAIDashboard.tsx # Dashboard avançado
│   ├── AIHeader.tsx            # Cabeçalho
│   ├── AIServicesStatus.tsx    # Status dos serviços
│   ├── AIStats.tsx             # Estatísticas
│   ├── AIFeatures.tsx          # Grid de funcionalidades
│   ├── AIQuickActions.tsx      # Ações rápidas
│   ├── AIGeneration.tsx        # Interface de geração
│   ├── AIChat.tsx              # Chat inteligente
│   ├── AIHistory.tsx           # Histórico
│   ├── AIAnalytics.tsx         # Analytics
│   ├── AIFilters.tsx           # Filtros
│   ├── AIActions.tsx           # Ações
│   ├── AIBreadcrumbs.tsx       # Navegação
│   └── AIIntegrationTest.tsx   # Teste de integração
├── pages/                       # Páginas do módulo
│   ├── index.ts
│   ├── AIIndexPage.tsx         # Página principal
│   ├── AIDetailPage.tsx        # Página de detalhes
│   └── AICreatePage.tsx        # Página de criação
├── utils/                       # Funções utilitárias
│   ├── index.ts
│   ├── aiHelpers.ts            # Funções auxiliares
│   ├── aiFormatters.ts         # Formatação de dados
│   ├── aiValidators.ts         # Validações
│   └── aiConstants.ts          # Constantes
├── tests/                       # Testes
│   ├── ai.test.ts              # Testes unitários
│   ├── ai.integration.test.ts  # Testes de integração
│   └── __mocks__/
│       └── aiService.ts        # Mocks para testes
└── README.md                   # Esta documentação
```

## Funcionalidades Principais

### 1. Geração de Conteúdo
- **Texto**: Geração de textos inteligentes com múltiplos provedores
- **Imagem**: Criação de imagens com IA (DALL-E, Midjourney, etc.)
- **Vídeo**: Geração de vídeos com IA (Runway, Pika, etc.)

### 2. Chat Inteligente
- Conversação em tempo real com IA
- Histórico de conversas
- Contexto mantido entre sessões
- Suporte a múltiplos modelos

### 3. Analytics Avançados
- Métricas de uso em tempo real
- Análise de custos
- Performance por provedor
- Relatórios personalizados

### 4. Gerenciamento de Provedores
- Integração com OpenAI, Claude, Gemini
- Status de disponibilidade
- Balanceamento de carga
- Fallback automático

### 5. Histórico e Persistência
- Armazenamento de gerações
- Histórico de chat
- Análises salvas
- Exportação de dados

## Uso

### Hook Principal - useAI

```typescript
import { useAI } from '@/modules/AI';

const MyComponent = () => {
  const {
    loading,
    error,
    generations,
    currentGeneration,
    providers,
    chatHistory,
    analytics,
    loadGenerations,
    createGeneration,
    updateGeneration,
    deleteGeneration,
    clearError,
    refresh
  } = useAI();

  const handleGenerateText = async () => {
    try {
      const generationData = {
        prompt: 'Crie um texto sobre IA',
        type: 'text',
        provider: 'openai',
        model: 'gpt-4'
      };
      
      const result = await createGeneration(generationData);
      console.log('Geração criada:', result);
    } catch (error) {
      console.error('Erro na geração:', error);
    }
  };

  const handleLoadGenerations = async () => {
    try {
      await loadGenerations({ type: 'text', limit: 10 });
    } catch (error) {
      console.error('Erro ao carregar gerações:', error);
    }
  };

  return (
    <div>
      <h2>Total de Gerações: {analytics?.totalGenerations || 0}</h2>
      <button onClick={handleGenerateText} disabled={loading}>
        {loading ? 'Gerando...' : 'Gerar Texto'}
      </button>
      <button onClick={handleLoadGenerations}>
        Carregar Gerações
      </button>
      {error && (
        <div className="error">
          {error}
          <button onClick={clearError}>Limpar Erro</button>
        </div>
      )}
    </div>
  );
};
```

### Hooks Especializados

#### useAIGeneration
```typescript
import { useAIGeneration } from '@/modules/AI';

const GenerationComponent = () => {
  const {
    generations,
    currentGeneration,
    loading,
    error,
    loadGenerations,
    createGeneration,
    updateGeneration,
    deleteGeneration,
    clearError
  } = useAIGeneration();

  const handleCreateGeneration = async () => {
    try {
      const generation = await createGeneration({
        prompt: 'Crie um texto sobre marketing digital',
        type: 'text',
        provider: 'claude',
        model: 'claude-3-opus'
      });
      console.log('Geração criada:', generation);
    } catch (error) {
      console.error('Erro:', error);
    }
  };

  return (
    <div>
      <h3>Gerações: {generations.length}</h3>
      <button onClick={handleCreateGeneration} disabled={loading}>
        {loading ? 'Gerando...' : 'Criar Geração'}
      </button>
      {generations.map(gen => (
        <div key={gen.id}>
          <p>{gen.prompt}</p>
          <p>{gen.result}</p>
        </div>
      ))}
    </div>
  );
};
```

#### useAIProviders
```typescript
import { useAIProviders } from '@/modules/AI';

const ProvidersComponent = () => {
  const {
    providers,
    servicesStatus,
    loading,
    error,
    loadProviders,
    isProviderAvailable,
    getAvailableProviders,
    getBestProvider,
    getProviderInfo
  } = useAIProviders();

  const handleLoadProviders = async () => {
    try {
      await loadProviders();
    } catch (error) {
      console.error('Erro ao carregar provedores:', error);
    }
  };

  const bestTextProvider = getBestProvider('text');
  const availableProviders = getAvailableProviders();

  return (
    <div>
      <h3>Provedores Disponíveis: {availableProviders.length}</h3>
      <button onClick={handleLoadProviders} disabled={loading}>
        {loading ? 'Carregando...' : 'Carregar Provedores'}
      </button>
      
      {bestTextProvider && (
        <p>Melhor provedor para texto: {bestTextProvider}</p>
      )}
      
      {providers.map(provider => (
        <div key={provider.id}>
          <h4>{provider.name}</h4>
          <p>Status: {provider.status}</p>
          <p>Disponível: {isProviderAvailable(provider.id) ? 'Sim' : 'Não'}</p>
        </div>
      ))}
    </div>
  );
};
```

### Componentes

#### AIDashboard
```typescript
import { AIDashboard } from '@/modules/AI/components';

const Dashboard = () => {
  const handleAction = (action: string, data: any) => {
    switch (action) {
      case 'navigate':
        // Navegar para a página
        window.location.href = data.href;
        break;
      case 'refresh':
        // Atualizar dados
        console.log('Atualizando dados...');
        break;
    }
  };

  return (
    <div>
      {/* Dashboard básico */}
      <AIDashboard 
        variant="basic"
        onAction={handleAction}
        className="mb-6"
      />
      
      {/* Dashboard avançado */}
      <AIDashboard 
        variant="advanced"
        showAdvancedMetrics
        showRealTimeData
        showProviderStatus
        showCostAnalytics
        onAction={handleAction}
        className="mb-6"
      />
      
      {/* Dashboard revolucionário */}
      <AIDashboard 
        variant="revolutionary"
        showAdvancedMetrics
        showRealTimeData
        showProviderStatus
        showCostAnalytics
        onAction={handleAction}
        className="mb-6"
      />
    </div>
  );
};
```

#### AIHeader
```typescript
import { AIHeader } from '@/modules/AI/components';

const Header = () => {
  const handleSettings = () => {
    console.log('Abrindo configurações...');
  };

  const handleHelp = () => {
    console.log('Abrindo ajuda...');
  };

  const handleProfile = () => {
    console.log('Abrindo perfil...');
  };

  return (
    <AIHeader
      title="Meu Dashboard AI"
      subtitle="Gerencie suas gerações de IA"
      showStats={true}
      variant="advanced"
      onSettings={handleSettings}
      onHelp={handleHelp}
      onProfile={handleProfile}
    />
  );
};
```

#### AIStats
```typescript
import { AIStats } from '@/modules/AI/components';

const Stats = () => {
  return (
    <div>
      {/* Estatísticas básicas */}
      <AIStats variant="basic" />
      
      {/* Estatísticas avançadas */}
      <AIStats variant="advanced" />
      
      {/* Estatísticas revolucionárias */}
      <AIStats variant="revolutionary" />
    </div>
  );
};
```

## API

### useAI Hook

#### Estado
- `generation`: Estado das gerações
- `providers`: Estado dos provedores
- `history`: Estado do histórico
- `analytics`: Estado dos analytics
- `loading`: Estado de carregamento
- `error`: Estado de erro

#### Métodos de Geração
- `generateText(prompt, options)` - Gerar texto
- `generateImage(prompt, options)` - Gerar imagem
- `generateVideo(prompt, options)` - Gerar vídeo

#### Métodos de Provedores
- `loadProviders()` - Carregar provedores
- `checkProviderStatus(provider)` - Verificar status
- `getBestProvider(type)` - Obter melhor provedor

#### Métodos de Histórico
- `loadHistory()` - Carregar histórico
- `addChatMessage(message)` - Adicionar mensagem
- `clearChatHistory()` - Limpar histórico

#### Métodos de Analytics
- `loadAnalytics()` - Carregar analytics
- `getRealTimeData()` - Obter dados em tempo real
- `getStats()` - Obter estatísticas

### aiService

#### Geração
- `aiService.generateText(prompt, options)` - Gerar texto
- `aiService.generateImage(prompt, options)` - Gerar imagem
- `aiService.generateVideo(prompt, options)` - Gerar vídeo

#### Provedores
- `aiService.getProviders()` - Listar provedores
- `aiService.checkServiceStatus(service)` - Verificar status
- `aiService.getServicesStatus()` - Status geral

#### Analytics
- `aiService.getAnalytics()` - Analytics gerais
- `aiService.getRealTimeData()` - Dados em tempo real
- `aiService.getUsageStats()` - Estatísticas de uso

## Tipos

### AIGeneration
```typescript
interface AIGeneration {
  id: string;
  type: 'text' | 'image' | 'video';
  prompt: string;
  result: string;
  provider: string;
  timestamp: string;
  options?: any;
  status: 'pending' | 'completed' | 'failed';
}
```

### AIProvider
```typescript
interface AIProvider {
  id: string;
  name: string;
  type: 'text' | 'image' | 'video';
  status: 'active' | 'inactive' | 'error';
  config: {
    apiKey?: string;
    endpoint?: string;
    model?: string;
  };
}
```

### AIChatHistory
```typescript
interface AIChatHistory {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  metadata?: any;
}
```

### AIAnalytics
```typescript
interface AIAnalytics {
  totalGenerations: number;
  totalCost: number;
  averageTime: number;
  successRate: number;
  providerStats: Record<string, any>;
  timeRange: {
    start: string;
    end: string;
  };
}
```

## Testes

### Executar Testes

```bash
# Testes unitários
npm test -- --testPathPattern=ai.test.ts

# Testes de integração
npm test -- --testPathPattern=ai.integration.test.ts

# Todos os testes do módulo
npm test -- --testPathPattern=AI
```

### Cobertura de Testes

```bash
npm test -- --coverage --testPathPattern=AI
```

## Configuração

### Variáveis de Ambiente

```env
# OpenAI
OPENAI_API_KEY=your_openai_api_key
OPENAI_ORGANIZATION=your_organization_id

# Anthropic Claude
ANTHROPIC_API_KEY=your_anthropic_api_key

# Google Gemini
GOOGLE_AI_API_KEY=your_google_ai_api_key

# DALL-E
DALLE_API_KEY=your_dalle_api_key

# Outros provedores
RUNWAY_API_KEY=your_runway_api_key
MIDJOURNEY_API_KEY=your_midjourney_api_key
```

### Configuração de Provedores

```typescript
// config/aiProviders.ts
export const AI_PROVIDERS_CONFIG = {
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
    organization: process.env.OPENAI_ORGANIZATION,
    models: ['gpt-4', 'gpt-3.5-turbo']
  },
  claude: {
    apiKey: process.env.ANTHROPIC_API_KEY,
    models: ['claude-3-opus', 'claude-3-sonnet']
  },
  gemini: {
    apiKey: process.env.GOOGLE_AI_API_KEY,
    models: ['gemini-pro', 'gemini-pro-vision']
  }
};
```

## Troubleshooting

### Problemas Comuns

#### 1. Erro de API Key
```
Error: Invalid API key for OpenAI
```
**Solução:** Verifique se a API key está configurada corretamente nas variáveis de ambiente.

#### 2. Rate Limit Exceeded
```
Error: Rate limit exceeded for provider
```
**Solução:** Implemente retry com backoff exponencial ou use provedores alternativos.

#### 3. Geração Falhou
```
Error: Generation failed
```
**Solução:** Verifique o prompt, limite de tokens e status do provedor.

#### 4. Provedor Inativo
```
Error: Provider is inactive
```
**Solução:** Verifique o status do provedor e configure um provedor de fallback.

### Logs

```typescript
// Habilitar logs detalhados
localStorage.setItem('ai-debug', 'true');

// Ver logs no console
console.log('AI Debug:', window.aiDebug);
```

## Contribuição

### Padrões de Código

1. **TypeScript**: Use tipagem forte
2. **Componentes**: Máximo 200 linhas por componente
3. **Hooks**: Máximo 200 linhas por hook
4. **Services**: Máximo 300 linhas por service
5. **Testes**: Cobertura mínima de 80%

### Processo de Contribuição

1. Fork do repositório
2. Criar branch para feature
3. Implementar com testes
4. Criar Pull Request
5. Code review
6. Merge

### Checklist de PR

- [ ] Código segue padrões estabelecidos
- [ ] Testes passando
- [ ] Cobertura de testes adequada
- [ ] Documentação atualizada
- [ ] Sem breaking changes
- [ ] Performance testada

## Roadmap

### Versão 1.1
- [ ] Suporte a mais provedores de IA
- [ ] Geração de áudio
- [ ] Templates de prompts
- [ ] Colaboração em tempo real

### Versão 1.2
- [ ] IA para análise de dados
- [ ] Automação de workflows
- [ ] Integração com APIs externas
- [ ] Mobile app

### Versão 2.0
- [ ] IA personalizada
- [ ] Fine-tuning de modelos
- [ ] Enterprise features
- [ ] Advanced analytics

## Licença

Este módulo é parte do projeto xWin-Dash e está sob a mesma licença do projeto principal.

## Suporte

Para suporte técnico ou dúvidas sobre o módulo AI:

- **Email**: dev@xwin.com.br
- **Slack**: #ai-support
- **Documentação**: [docs.xwin.com.br/ai](https://docs.xwin.com.br/ai)
- **Issues**: [GitHub Issues](https://github.com/xwin/xwin-dash/issues)

---

**Última atualização**: Janeiro 2024  
**Versão**: 1.0.0  
**Mantenedor**: Equipe de Desenvolvimento xWin