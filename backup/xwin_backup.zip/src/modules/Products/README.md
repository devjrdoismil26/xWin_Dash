# 📦 Módulo Products - Documentação Completa

## 🎯 Visão Geral

O módulo **Products** é o núcleo do sistema xWin Dash para gerenciamento completo de produtos, landing pages e captura de leads. Ele suporta tanto produtos físicos quanto digitais, oferecendo uma solução integrada para e-commerce, marketing digital e gestão de leads.

## 🏗️ Arquitetura

### Estrutura Modular
```
Frontend/src/modules/Products/
├── components/           # Componentes React
│   ├── LandingPages/    # Builder de landing pages
│   ├── LeadCaptureForms/ # Formulários de captura
│   └── ...              # Outros componentes
├── hooks/               # Hooks React
│   ├── useProducts.ts   # Hook principal integrado
│   └── ...              # Hooks especializados
├── services/            # Serviços de API
│   ├── productsApiService.ts # Serviço principal
│   └── ...              # Serviços auxiliares
├── types/               # Definições TypeScript
│   └── index.ts         # Tipos unificados
└── README.md            # Esta documentação
```

## 🚀 Funcionalidades Principais

### 1. **Gerenciamento de Produtos**
- ✅ **Produtos Físicos** - Produtos tangíveis com controle de estoque
- ✅ **Produtos Digitais** - E-books, cursos, softwares, etc.
- ✅ **Serviços** - Serviços prestados
- ✅ **Assinaturas** - Produtos recorrentes
- ✅ **Pacotes/Bundles** - Conjuntos de produtos

### 2. **Landing Pages**
- ✅ **Builder Drag-and-Drop** - Criação visual de páginas
- ✅ **Templates Pré-definidos** - Templates profissionais
- ✅ **Sistema de Seções** - Hero, Features, Pricing, FAQ, CTA
- ✅ **A/B Testing** - Testes de conversão integrados
- ✅ **Analytics em Tempo Real** - Métricas de performance

### 3. **Captura de Leads**
- ✅ **Formulários Personalizáveis** - Campos customizáveis
- ✅ **Validação Avançada** - Validação em tempo real
- ✅ **Integração com Landing Pages** - Captura contextual
- ✅ **Scoring de Leads** - Pontuação automática
- ✅ **Workflows de Follow-up** - Automação de processos

### 4. **Analytics e Métricas**
- ✅ **Dashboard Unificado** - Visão geral completa
- ✅ **Métricas de Conversão** - Taxa de conversão por página/formulário
- ✅ **Análise de Tráfego** - Origem e comportamento dos visitantes
- ✅ **Relatórios Personalizáveis** - Relatórios sob demanda
- ✅ **Exportação de Dados** - CSV, Excel, PDF

## 🔧 Integração Backend

### Status da Integração: ✅ 100% COMPLETA

O módulo Products está completamente integrado com o backend Laravel através de:

#### 1. **Backend API Controller**
- **`ProductsApiController`** - Controller completo com 50+ endpoints
- Validação robusta de dados
- Tratamento de erros padronizado
- Logs de auditoria automáticos
- Respostas JSON consistentes

#### 2. **Frontend API Service**
- **`productsApiService`** - Serviço centralizado para comunicação
- Tratamento de erros unificado
- Interceptação de requisições
- Retry automático para falhas temporárias
- Cache inteligente de respostas

#### 3. **Hook Integrado**
- **`useProducts`** - Hook principal com todas as funcionalidades
- Estado sincronizado com backend
- Operações em tempo real
- Gerenciamento de loading/error states
- Cache local otimizado

## 📊 Tipos de Produtos Suportados

### Produtos Físicos
```typescript
interface PhysicalProduct {
  type: 'physical';
  dimensions: ProductDimensions;
  weight: number;
  inventory: ProductInventory;
  shipping: ShippingSettings;
}
```

### Produtos Digitais
```typescript
interface DigitalProduct {
  type: 'digital';
  download_url?: string;
  access_duration?: number;
  license_type?: string;
  delivery_method: 'instant' | 'email' | 'manual';
}
```

### Serviços
```typescript
interface ServiceProduct {
  type: 'service';
  duration?: number;
  location?: string;
  booking_required: boolean;
  capacity?: number;
}
```

### Assinaturas
```typescript
interface SubscriptionProduct {
  type: 'subscription';
  billing_cycle: 'monthly' | 'yearly' | 'weekly';
  trial_period?: number;
  auto_renewal: boolean;
  cancellation_policy: string;
}
```

## 🎨 Builder de Landing Pages

### Seções Disponíveis
- **Hero** - Seção principal com CTA
- **Features** - Características do produto/serviço
- **Testimonials** - Depoimentos de clientes
- **Pricing** - Tabela de preços
- **FAQ** - Perguntas frequentes
- **CTA** - Call-to-action
- **Contact** - Formulário de contato
- **Custom** - Seções personalizadas

### Templates Incluídos
- **E-commerce** - Para produtos físicos
- **Digital Products** - Para produtos digitais
- **Services** - Para prestação de serviços
- **SaaS** - Para software como serviço
- **Lead Generation** - Para captura de leads

## 📝 Formulários de Captura

### Campos Suportados
- **Texto** - Campos de texto simples
- **Email** - Validação de email
- **Telefone** - Formatação automática
- **Número** - Campos numéricos
- **Select** - Lista de opções
- **Multi-select** - Múltiplas seleções
- **Checkbox** - Caixas de seleção
- **Radio** - Botões de opção
- **Textarea** - Área de texto
- **Data** - Seletor de data
- **Arquivo** - Upload de arquivos

### Validações Disponíveis
- **Obrigatório** - Campo obrigatório
- **Comprimento mínimo/máximo** - Limites de caracteres
- **Padrão regex** - Validação personalizada
- **Mensagem customizada** - Mensagens de erro personalizadas

## 📈 Analytics e Métricas

### Métricas de Produtos
- Total de produtos
- Produtos ativos/inativos
- Produtos por categoria
- Valor total do estoque
- Produtos com estoque baixo
- Top produtos vendidos

### Métricas de Landing Pages
- Total de visualizações
- Taxa de conversão
- Tempo médio na página
- Taxa de rejeição
- Origem do tráfego
- Dispositivos utilizados

### Métricas de Formulários
- Total de envios
- Taxa de conversão
- Campos mais preenchidos
- Tempo médio de preenchimento
- Taxa de abandono por campo

### Métricas de Leads
- Total de leads
- Leads por status
- Taxa de conversão
- Score médio dos leads
- Origem dos leads
- Tempo médio de conversão

## 🔄 Fluxo de Trabalho

### 1. Criação de Produto
```
Projeto → Produto → Configuração → Publicação
```

### 2. Criação de Landing Page
```
Produto → Template → Customização → Teste A/B → Publicação
```

### 3. Captura de Leads
```
Landing Page → Formulário → Validação → Lead → Follow-up
```

### 4. Conversão
```
Lead → Qualificação → Proposta → Fechamento → Cliente
```

## 🚀 Como Usar

### Instalação Básica
```tsx
import { useProducts } from '@/modules/Products/hooks/useProducts';

function ProductsDashboard() {
  const {
    products,
    loading,
    error,
    loadProducts,
    createProduct
  } = useProducts();

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  return (
    <div>
      {loading && <LoadingSpinner />}
      {error && <ErrorMessage error={error} />}
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
```

### Criação de Produto
```tsx
const createNewProduct = async () => {
  const productData = {
    name: 'Meu Produto',
    description: 'Descrição do produto',
    price: 99.90,
    currency: 'BRL',
    category: 'digital',
    type: 'digital',
    tags: ['produto', 'digital'],
    images: [imageFile],
    sku: 'PROD-001',
    inventory: {
      quantity: 100,
      track_inventory: false,
      allow_backorder: false
    },
    seo: {
      meta_title: 'Meu Produto - SEO Title',
      meta_description: 'Descrição para SEO',
      slug: 'meu-produto'
    }
  };

  try {
    const newProduct = await createProduct(productData);
    console.log('Produto criado:', newProduct);
  } catch (error) {
    console.error('Erro ao criar produto:', error);
  }
};
```

### Criação de Landing Page
```tsx
const createLandingPage = async () => {
  const landingPageData = {
    name: 'Landing Page do Produto',
    title: 'Descubra Nosso Produto',
    description: 'Landing page para conversão',
    product_id: product.id,
    template: 'digital-product'
  };

  try {
    const newLandingPage = await createLandingPage(landingPageData);
    console.log('Landing page criada:', newLandingPage);
  } catch (error) {
    console.error('Erro ao criar landing page:', error);
  }
};
```

### Criação de Formulário de Captura
```tsx
const createLeadForm = async () => {
  const formData = {
    name: 'Formulário de Contato',
    title: 'Entre em Contato',
    description: 'Formulário para captura de leads',
    fields: [
      {
        id: 'name',
        type: 'text',
        label: 'Nome',
        placeholder: 'Seu nome completo',
        required: true,
        order: 1
      },
      {
        id: 'email',
        type: 'email',
        label: 'Email',
        placeholder: 'seu@email.com',
        required: true,
        order: 2
      },
      {
        id: 'phone',
        type: 'phone',
        label: 'WhatsApp',
        placeholder: '(11) 99999-9999',
        required: false,
        order: 3
      }
    ],
    settings: {
      submit_text: 'Enviar Mensagem',
      success_message: 'Obrigado! Entraremos em contato em breve.',
      email_notifications: true,
      auto_responder: true
    }
  };

  try {
    const newForm = await createForm(formData);
    console.log('Formulário criado:', newForm);
  } catch (error) {
    console.error('Erro ao criar formulário:', error);
  }
};
```

### Gerenciamento de Leads
```tsx
const manageLeads = async () => {
  // Carregar leads
  await loadLeads({ status: ['new', 'contacted'] });
  
  // Atualizar status do lead
  await updateLeadStatus(leadId, 'qualified');
  
  // Atualizar score do lead
  await updateLeadScore(leadId, 85);
  
  // Exportar leads
  await exportLeads({ status: ['converted'] });
};
```

## 📊 Estatísticas e Relatórios

### Dashboard Principal
```tsx
const Dashboard = () => {
  const {
    productsStats,
    landingPagesStats,
    formsStats,
    leadsStats,
    loadProductsStats,
    loadLandingPagesStats,
    loadFormsStats,
    loadLeadsStats
  } = useProducts();

  useEffect(() => {
    loadProductsStats();
    loadLandingPagesStats();
    loadFormsStats();
    loadLeadsStats();
  }, []);

  return (
    <div className="dashboard">
      <StatsCard title="Produtos" stats={productsStats} />
      <StatsCard title="Landing Pages" stats={landingPagesStats} />
      <StatsCard title="Formulários" stats={formsStats} />
      <StatsCard title="Leads" stats={leadsStats} />
    </div>
  );
};
```

## 🔧 Operações em Lote

### Atualização em Lote de Produtos
```tsx
const bulkUpdateProducts = async () => {
  const productIds = [1, 2, 3, 4, 5];
  const updates = {
    status: 'active',
    category: 'digital'
  };

  try {
    await bulkUpdateProducts(productIds, updates);
    console.log('Produtos atualizados em lote');
  } catch (error) {
    console.error('Erro na atualização em lote:', error);
  }
};
```

### Exclusão em Lote
```tsx
const bulkDeleteProducts = async () => {
  const productIds = [1, 2, 3];

  try {
    await bulkDeleteProducts(productIds);
    console.log('Produtos excluídos em lote');
  } catch (error) {
    console.error('Erro na exclusão em lote:', error);
  }
};
```

## 📤 Import/Export

### Importação de Produtos
```tsx
const importProducts = async (file: File) => {
  try {
    await importProducts(file, projectId);
    console.log('Produtos importados com sucesso');
  } catch (error) {
    console.error('Erro na importação:', error);
  }
};
```

### Exportação de Dados
```tsx
const exportData = async () => {
  try {
    // Exportar produtos
    await exportProducts({ category: ['digital'] });
    
    // Exportar leads
    await exportLeads({ status: ['converted'] });
    
    console.log('Dados exportados com sucesso');
  } catch (error) {
    console.error('Erro na exportação:', error);
  }
};
```

## 🎯 Melhores Práticas

### 1. **Organização de Produtos**
- Use categorias consistentes
- Mantenha SKUs únicos
- Configure estoque adequadamente
- Otimize imagens para web

### 2. **Landing Pages**
- Teste diferentes versões (A/B)
- Otimize para mobile
- Use CTAs claros e visíveis
- Monitore métricas de conversão

### 3. **Formulários de Captura**
- Minimize campos obrigatórios
- Use validação em tempo real
- Teste diferentes layouts
- Configure follow-up automático

### 4. **Gestão de Leads**
- Qualifique leads rapidamente
- Use scoring consistente
- Automatize workflows
- Monitore conversões

## 🔒 Segurança e Validação

### Validação de Dados
- Validação client-side e server-side
- Sanitização de inputs
- Proteção contra XSS
- Validação de tipos TypeScript

### Controle de Acesso
- Autenticação obrigatória
- Autorização por projeto
- Logs de auditoria
- Rate limiting

## 📱 Responsividade

### Design Mobile-First
- Layout responsivo
- Touch-friendly interfaces
- Performance otimizada
- Progressive Web App ready

## 🚀 Performance

### Otimizações Implementadas
- Lazy loading de componentes
- Cache inteligente
- Debounce em pesquisas
- Virtualização de listas
- Compressão de imagens

## 🧪 Testes

### Cobertura de Testes
- Testes unitários (Vitest)
- Testes de integração
- Testes E2E (Playwright)
- Testes de performance

## 📚 Recursos Adicionais

### Documentação Técnica
- [API Reference](./docs/api.md)
- [Component Library](./docs/components.md)
- [Hooks Guide](./docs/hooks.md)
- [Types Reference](./docs/types.md)

### Exemplos Práticos
- [E-commerce Setup](./examples/ecommerce.md)
- [Lead Generation](./examples/leadgen.md)
- [Digital Products](./examples/digital.md)
- [Services Business](./examples/services.md)

---

**O módulo Products representa a espinha dorsal do sistema xWin Dash, oferecendo uma solução completa e integrada para gerenciamento de produtos, marketing digital e captura de leads! 🎉**