import React from 'react';
const TeamWorkspace = () => (
  <div className="p-6">Workspace de Equipe</div>
);
export default TeamWorkspace;
