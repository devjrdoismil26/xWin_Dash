import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { analyticsService } from '../services/analyticsService';
import type {
  AnalyticsParams,
  BasicMetrics,
  PlatformMetrics,
  TimeSeriesMetrics,
  ContentMetrics,
  HashtagMetrics,
  LinkMetrics,
  EngagementMetrics,
  AudienceMetrics,
  AnalyticsReport,
  PeriodComparison
} from '../services/analyticsService';

interface AnalyticsState {
  // Estado das métricas
  basicMetrics: BasicMetrics | null;
  platformMetrics: PlatformMetrics[];
  timeSeriesMetrics: TimeSeriesMetrics[];
  contentMetrics: ContentMetrics[];
  hashtagMetrics: HashtagMetrics[];
  linkMetrics: LinkMetrics[];
  engagementMetrics: EngagementMetrics | null;
  audienceMetrics: AudienceMetrics | null;
  
  // Estado de relatórios
  currentReport: AnalyticsReport | null;
  periodComparison: PeriodComparison | null;
  
  // Estado de filtros
  filters: AnalyticsParams;
  
  // Estado de loading e erro
  loading: boolean;
  error: string | null;
  
  // Estado de operações
  generatingReport: boolean;
  exporting: boolean;
  comparing: boolean;
  
  // Estado de insights
  insights: {
    insights: string[];
    recommendations: string[];
    trends: Array<{
      metric: string;
      trend: 'up' | 'down' | 'stable';
      percentage: number;
      description: string;
    }>;
  } | null;
  
  // Estado de tempo real
  realTimeMetrics: {
    active_posts: number;
    scheduled_posts: number;
    total_engagement_today: number;
    total_reach_today: number;
    top_performing_post: any | null;
    recent_activity: Array<{
      type: string;
      description: string;
      timestamp: string;
      value?: number;
    }>;
  } | null;
}

interface AnalyticsActions {
  // Ações de métricas básicas
  fetchBasicMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshBasicMetrics: () => Promise<void>;
  
  // Ações de métricas por plataforma
  fetchPlatformMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshPlatformMetrics: () => Promise<void>;
  
  // Ações de métricas temporais
  fetchTimeSeriesMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshTimeSeriesMetrics: () => Promise<void>;
  
  // Ações de métricas de conteúdo
  fetchContentMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshContentMetrics: () => Promise<void>;
  
  // Ações de métricas de hashtags
  fetchHashtagMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshHashtagMetrics: () => Promise<void>;
  
  // Ações de métricas de links
  fetchLinkMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshLinkMetrics: () => Promise<void>;
  
  // Ações de métricas de engajamento
  fetchEngagementMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshEngagementMetrics: () => Promise<void>;
  
  // Ações de métricas de audiência
  fetchAudienceMetrics: (params?: AnalyticsParams) => Promise<void>;
  refreshAudienceMetrics: () => Promise<void>;
  
  // Ações de relatórios
  generateReport: (params?: AnalyticsParams) => Promise<void>;
  exportReport: (format: 'pdf' | 'excel' | 'csv') => Promise<Blob>;
  
  // Ações de comparação
  comparePeriods: (currentParams: AnalyticsParams, previousParams: AnalyticsParams) => Promise<void>;
  
  // Ações de insights
  fetchInsights: (params?: AnalyticsParams) => Promise<void>;
  refreshInsights: () => Promise<void>;
  
  // Ações de tempo real
  fetchRealTimeMetrics: () => Promise<void>;
  refreshRealTimeMetrics: () => Promise<void>;
  
  // Ações de performance de posts
  fetchPostPerformance: (postIds: string[]) => Promise<any[]>;
  
  // Ações de performance de contas
  fetchAccountPerformance: (accountIds: string[]) => Promise<any[]>;
  
  // Ações de filtros
  setFilters: (filters: Partial<AnalyticsParams>) => void;
  clearFilters: () => void;
  
  // Ações de estado
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearError: () => void;
  
  // Ações de limpeza
  clearAllMetrics: () => void;
  clearReport: () => void;
  clearComparison: () => void;
}

type AnalyticsStore = AnalyticsState & AnalyticsActions;

const initialState: AnalyticsState = {
  basicMetrics: null,
  platformMetrics: [],
  timeSeriesMetrics: [],
  contentMetrics: [],
  hashtagMetrics: [],
  linkMetrics: [],
  engagementMetrics: null,
  audienceMetrics: null,
  currentReport: null,
  periodComparison: null,
  filters: {},
  loading: false,
  error: null,
  generatingReport: false,
  exporting: false,
  comparing: false,
  insights: null,
  realTimeMetrics: null
};

export const useAnalyticsStore = create<AnalyticsStore>()(
  devtools(
    persist(
      (set, get) => ({
        ...initialState,

        // Ações de métricas básicas
        fetchBasicMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getBasicMetrics(searchParams);
            
            set({
              basicMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas básicas',
              loading: false
            });
          }
        },

        refreshBasicMetrics: async () => {
          const { fetchBasicMetrics, filters } = get();
          await fetchBasicMetrics(filters);
        },

        // Ações de métricas por plataforma
        fetchPlatformMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getPlatformMetrics(searchParams);
            
            set({
              platformMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas por plataforma',
              loading: false
            });
          }
        },

        refreshPlatformMetrics: async () => {
          const { fetchPlatformMetrics, filters } = get();
          await fetchPlatformMetrics(filters);
        },

        // Ações de métricas temporais
        fetchTimeSeriesMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getTimeSeriesMetrics(searchParams);
            
            set({
              timeSeriesMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas temporais',
              loading: false
            });
          }
        },

        refreshTimeSeriesMetrics: async () => {
          const { fetchTimeSeriesMetrics, filters } = get();
          await fetchTimeSeriesMetrics(filters);
        },

        // Ações de métricas de conteúdo
        fetchContentMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getContentMetrics(searchParams);
            
            set({
              contentMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas de conteúdo',
              loading: false
            });
          }
        },

        refreshContentMetrics: async () => {
          const { fetchContentMetrics, filters } = get();
          await fetchContentMetrics(filters);
        },

        // Ações de métricas de hashtags
        fetchHashtagMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getHashtagMetrics(searchParams);
            
            set({
              hashtagMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas de hashtags',
              loading: false
            });
          }
        },

        refreshHashtagMetrics: async () => {
          const { fetchHashtagMetrics, filters } = get();
          await fetchHashtagMetrics(filters);
        },

        // Ações de métricas de links
        fetchLinkMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getLinkMetrics(searchParams);
            
            set({
              linkMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas de links',
              loading: false
            });
          }
        },

        refreshLinkMetrics: async () => {
          const { fetchLinkMetrics, filters } = get();
          await fetchLinkMetrics(filters);
        },

        // Ações de métricas de engajamento
        fetchEngagementMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getEngagementMetrics(searchParams);
            
            set({
              engagementMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas de engajamento',
              loading: false
            });
          }
        },

        refreshEngagementMetrics: async () => {
          const { fetchEngagementMetrics, filters } = get();
          await fetchEngagementMetrics(filters);
        },

        // Ações de métricas de audiência
        fetchAudienceMetrics: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const metrics = await analyticsService.getAudienceMetrics(searchParams);
            
            set({
              audienceMetrics: metrics,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas de audiência',
              loading: false
            });
          }
        },

        refreshAudienceMetrics: async () => {
          const { fetchAudienceMetrics, filters } = get();
          await fetchAudienceMetrics(filters);
        },

        // Ações de relatórios
        generateReport: async (params?: AnalyticsParams) => {
          try {
            set({ generatingReport: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const report = await analyticsService.generateReport(searchParams);
            
            set({
              currentReport: report,
              generatingReport: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao gerar relatório',
              generatingReport: false
            });
          }
        },

        exportReport: async (format: 'pdf' | 'excel' | 'csv') => {
          try {
            set({ exporting: true, error: null });
            
            const { filters } = get();
            const blob = await analyticsService.exportReport(filters, format);
            
            set({ exporting: false });
            return blob;
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao exportar relatório',
              exporting: false
            });
            throw error;
          }
        },

        // Ações de comparação
        comparePeriods: async (currentParams: AnalyticsParams, previousParams: AnalyticsParams) => {
          try {
            set({ comparing: true, error: null });
            
            const comparison = await analyticsService.comparePeriods(currentParams, previousParams);
            
            set({
              periodComparison: comparison,
              comparing: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao comparar períodos',
              comparing: false
            });
          }
        },

        // Ações de insights
        fetchInsights: async (params?: AnalyticsParams) => {
          try {
            set({ loading: true, error: null });
            
            const currentFilters = get().filters;
            const searchParams = { ...currentFilters, ...params };
            
            const insights = await analyticsService.getInsights(searchParams);
            
            set({
              insights,
              loading: false
            });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar insights',
              loading: false
            });
          }
        },

        refreshInsights: async () => {
          const { fetchInsights, filters } = get();
          await fetchInsights(filters);
        },

        // Ações de tempo real
        fetchRealTimeMetrics: async () => {
          try {
            const metrics = await analyticsService.getRealTimeMetrics();
            set({ realTimeMetrics: metrics });
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar métricas em tempo real'
            });
          }
        },

        refreshRealTimeMetrics: async () => {
          const { fetchRealTimeMetrics } = get();
          await fetchRealTimeMetrics();
        },

        // Ações de performance de posts
        fetchPostPerformance: async (postIds: string[]) => {
          try {
            const performance = await analyticsService.getPostPerformance(postIds);
            return performance;
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar performance dos posts'
            });
            throw error;
          }
        },

        // Ações de performance de contas
        fetchAccountPerformance: async (accountIds: string[]) => {
          try {
            const performance = await analyticsService.getAccountPerformance(accountIds);
            return performance;
          } catch (error) {
            set({
              error: error instanceof Error ? error.message : 'Erro ao carregar performance das contas'
            });
            throw error;
          }
        },

        // Ações de filtros
        setFilters: (filters: Partial<AnalyticsParams>) => {
          set((state) => ({
            filters: { ...state.filters, ...filters }
          }));
        },

        clearFilters: () => {
          set({ filters: {} });
        },

        // Ações de estado
        setLoading: (loading: boolean) => {
          set({ loading });
        },

        setError: (error: string | null) => {
          set({ error });
        },

        clearError: () => {
          set({ error: null });
        },

        // Ações de limpeza
        clearAllMetrics: () => {
          set({
            basicMetrics: null,
            platformMetrics: [],
            timeSeriesMetrics: [],
            contentMetrics: [],
            hashtagMetrics: [],
            linkMetrics: [],
            engagementMetrics: null,
            audienceMetrics: null,
            insights: null,
            realTimeMetrics: null
          });
        },

        clearReport: () => {
          set({ currentReport: null });
        },

        clearComparison: () => {
          set({ periodComparison: null });
        }
      }),
      {
        name: 'socialbuffer-analytics-store',
        partialize: (state) => ({
          filters: state.filters
        })
      }
    ),
    {
      name: 'SocialBufferAnalyticsStore'
    }
  )
);

export default useAnalyticsStore;
