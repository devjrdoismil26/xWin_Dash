# 📁 Projects Module - xWin Dash

## 🎯 Visão Geral

O módulo Projects é o **centro de controle** da aplicação xWin Dash. Após o login, os usuários são direcionados para a **seleção de projetos**, onde podem gerenciar seus projetos e acessar o **Modo Universe**.

## 🏗️ Estrutura Organizada

```
Projects/
├── ProjectSelector.tsx          # 🎯 Página principal pós-login
├── components/                  # Componentes principais
│   ├── ProjectsModule.tsx       # Módulo principal
│   ├── ProjectsDashboard.tsx    # Dashboard de projetos
│   ├── ProjectsHeader.tsx       # Cabeçalho
│   ├── ProjectsNavigation.tsx   # Navegação lateral
│   └── ...                     # Outros componentes
├── Universe/                    # 🌌 Submodulo Universe
│   ├── index.tsx               # Interface principal
│   ├── components/            # Componentes Universe
│   ├── blocks/                 # Blocos drag & drop
│   ├── hooks/                  # Hooks específicos
│   └── services/               # Serviços Universe
├── ProjectsCore/               # 🔧 Funcionalidades básicas
├── ProjectsManager/            # 📊 Gerenciamento avançado
├── ProjectsAdvanced/           # 🚀 Recursos avançados
├── hooks/                      # Hooks do módulo
├── services/                   # Serviços
├── types/                      # Tipos TypeScript
└── index.tsx                   # Exports principais
```

## 🔄 Fluxo de Navegação

### 1. **Login** → **ProjectSelector**
- Usuário faz login
- Redirecionado para `/projects` (ProjectSelector)
- Vê lista de projetos existentes
- Pode criar novos projetos
- Acesso direto ao Modo Universe

### 2. **Seleção de Projeto** → **Dashboard**
- Usuário seleciona um projeto
- Projeto armazenado na sessão
- Redirecionado para `/dashboard`
- Dashboard só aparece com projeto ativo

### 3. **Modo Universe**
- Acessível diretamente da ProjectSelector
- Interface drag & drop avançada
- Submodulo completo dentro de Projects

## 🎨 Componentes Principais

### ProjectSelector.tsx
- **Função**: Página principal pós-login
- **Recursos**: 
  - Lista de projetos
  - Criação de projetos
  - Busca e filtros
  - Acesso ao Universe
  - Seleção de projeto

### ProjectsModule.tsx
- **Função**: Interface principal de projetos
- **Recursos**:
  - Navegação entre projetos
  - Acesso ao Universe
  - Gerenciamento de projetos

### Universe/
- **Função**: Submodulo de interface avançada
- **Recursos**:
  - Drag & drop
  - Blocos modulares
  - IA integrada
  - Automação

## 🔧 Submodulos

### ProjectsCore
- Funcionalidades básicas de projetos
- CRUD simples
- Operações fundamentais

### ProjectsManager
- Gerenciamento avançado
- Membros e permissões
- Configurações

### ProjectsAdvanced
- Recursos avançados
- Analytics e relatórios
- Templates e automação

## 🎯 Tipos Principais

```typescript
interface Project {
  id: number;
  name: string;
  description: string;
  mode: 'normal' | 'universe';
  status: 'active' | 'inactive' | 'archived';
  members_count: number;
  created_at: string;
  updated_at: string;
  modules?: string[];
}
```

## 🚀 Funcionalidades

### ✅ Implementadas
- [x] Seleção de projetos pós-login
- [x] Criação de projetos
- [x] Modo Universe integrado
- [x] Dashboard condicional
- [x] Navegação organizada
- [x] Tipos unificados

### 🔄 Em Desenvolvimento
- [ ] Integração completa com backend
- [ ] Gerenciamento de membros
- [ ] Analytics avançados
- [ ] Templates de projetos

## 📝 Notas Importantes

1. **Universe é submodulo**: Mantém-se dentro de Projects
2. **Dashboard condicional**: Só aparece com projeto selecionado
3. **Tipos unificados**: Uma única fonte de verdade
4. **Estrutura limpa**: Arquivos obsoletos removidos
5. **Navegação clara**: Fluxo intuitivo pós-login

## 🔗 Integração com Backend

- **Rotas**: `/projects`, `/dashboard`, `/projects/universe`
- **Middleware**: `project.selected` para verificar projeto ativo
- **Sessão**: `selected_project_id` armazenado na sessão
- **Modelo**: `Project` com relacionamentos

---

**Última atualização**: Setembro 2024  
**Status**: ✅ Estrutura organizada e funcional