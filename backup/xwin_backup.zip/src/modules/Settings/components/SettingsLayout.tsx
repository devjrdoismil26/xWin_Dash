import React from 'react';
const SettingsLayout = ({ children }) => (
  <div className="p-6">
    {children}
  </div>
);
export default SettingsLayout;
