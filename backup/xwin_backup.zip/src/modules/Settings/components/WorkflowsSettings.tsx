import React from 'react';
import Card from '@/components/ui/Card';
const WorkflowsSettings = () => (
  <Card>
    <Card.Header>
      <Card.Title>Workflows</Card.Title>
    </Card.Header>
    <Card.Content>
      <p>Configurações básicas de workflows.</p>
    </Card.Content>
  </Card>
);
export default WorkflowsSettings;
