# Módulos Frontend - xWin Dash

Este diretório contém todos os módulos do frontend da aplicação xWin Dash, organizados seguindo a arquitetura Domain-Driven Design (DDD) do backend.

## 📁 Estrutura dos Módulos

### Módulos Principais Existentes
- **Dashboard** - Painel principal com métricas e visão geral
- **AI** - Inteligência artificial e geração de conteúdo
- **Leads** - Gestão de leads e CRM
- **EmailMarketing** - Campanhas de email marketing
- **SocialBuffer** - Gestão de redes sociais
- **Workflows** - Designer de processos e automações
- **Aura** - Integração WhatsApp Business
- **ADStool** - Gestão de anúncios (Google Ads, Facebook)
- **Projects** - Gestão de projetos e multi-tenancy
- **Analytics** - Business Intelligence e relatórios
- **MediaLibrary** - Gestão de arquivos e mídia
- **Settings** - Configurações gerais do usuário

### 🆕 Novos Módulos Criados

#### **Categorization**
Sistema completo de categorização e tags
- `Categories/Index.tsx` - Lista de categorias
- `Categories/CreateEdit.tsx` - Criar/editar categorias
- `Tags/Index.tsx` - Lista de tags
- `Tags/CreateEdit.tsx` - Criar/editar tags
- **Funcionalidades:**
  - Gestão hierárquica de categorias
  - Sistema de tags com cores personalizadas
  - Busca e filtros avançados
  - Estatísticas de uso

#### **NodeRed**
Editor visual de fluxos e automações
- `Editor/index.tsx` - Editor visual completo
- `Flows/Index.tsx` - Gestão de fluxos
- **Funcionalidades:**
  - Interface similar ao Node-RED oficial
  - Palette de nós organizados por categoria
  - Workspace com grid e conexões visuais
  - Deploy e gerenciamento de fluxos
  - Debug em tempo real

#### **Core**
Sistema central de configurações e monitoramento
- `Settings/Index.tsx` - Configurações do sistema
- **Funcionalidades:**
  - Configurações gerais da aplicação
  - Informações da empresa
  - Configurações de email (SMTP)
  - Performance e cache
  - Segurança e políticas
  - Monitoramento de sistema
  - Status de serviços

#### **Integrations**
Gestão de integrações externas
- **Funcionalidades:**
  - Catálogo de integrações disponíveis
  - Status de conexões ativas
  - Logs de atividades das integrações
  - Configuração de APIs e webhooks
  - Monitoramento de requisições

#### **Activity**
Log completo de atividades do sistema
- **Funcionalidades:**
  - Histórico de todas as ações
  - Filtros por tipo, usuário e data
  - Detalhes de alterações (audit trail)
  - Logs de segurança
  - Exportação de relatórios

### 🔧 Módulos AI Aprimorados

#### **ImageGeneration**
Geração de imagens com IA
- **Funcionalidades:**
  - Interface para DALL-E, Midjourney, Stable Diffusion
  - Configuração de prompts e parâmetros
  - Preview em tempo real
  - Histórico de gerações
  - Download e compartilhamento

#### **TextAnalysis**
Análise avançada de texto
- **Funcionalidades:**
  - Análise de sentimento com emoções
  - Extração de palavras-chave e entidades
  - Resumos automáticos
  - Suporte a múltiplos idiomas

#### **QuestionAnswering**
Sistema de perguntas e respostas
- **Funcionalidades:**
  - Chat interativo com IA
  - Contexto personalizado
  - Múltiplos modelos (GPT-4, Claude)
  - Fontes e confiança das respostas

## 🎨 Padrões de Design

### Estrutura de Componentes
```typescript
// Estrutura padrão de um módulo
const ModuleName: React.FC<Props> = ({ auth, data, filters }) => {
  return (
    <AppLayout
      title="Título do Módulo"
      subtitle="Descrição do módulo"
      showSidebar={true}
      showBreadcrumbs={true}
      breadcrumbs={[...]}
      actions={<Button>Ação Principal</Button>}
    >
      <Head title="Título - xWin Dash" />
      
      <div className="space-y-6">
        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Cards de métricas */}
        </div>

        {/* Filtros */}
        <Card>
          {/* Componentes de busca e filtro */}
        </Card>

        {/* Conteúdo principal */}
        <Card>
          {/* Lista, tabela ou conteúdo */}
        </Card>
      </div>
    </AppLayout>
  );
};
```

### Componentes Utilizados
- **AppLayout** - Layout principal com sidebar e breadcrumbs
- **Card** - Container principal para seções
- **Button** - Botões com variantes (primary, outline, ghost)
- **Input/Textarea** - Campos de formulário
- **SimpleSelect** - Seleção dropdown
- **Badge** - Indicadores de status
- **Icons** - Lucide React para ícones consistentes

### Estados e Interações
- **Loading States** - Indicadores de carregamento
- **Empty States** - Estados vazios com call-to-action
- **Error Handling** - Tratamento de erros com feedback visual
- **Responsive Design** - Grid responsivo para diferentes telas

## 🔄 Integração com Backend

### Rotas Correspondentes
Cada módulo frontend corresponde às rotas do backend:
- `/categorization/*` → `Backend/app/Domains/Categorization/`
- `/nodered/*` → `Backend/app/Domains/NodeRed/`
- `/core/*` → `Backend/app/Domains/Core/`
- `/integrations/*` → `Backend/app/Domains/Integrations/`
- `/activity/*` → `Backend/app/Domains/Activity/`

### Formulários e Validação
- Uso do `useForm` do Inertia.js
- Validação client-side e server-side
- Feedback visual de erros
- Estados de processamento

### Navegação
- Uso do `router` do Inertia.js
- Breadcrumbs automáticos
- Links contextuais entre módulos

## 📊 Funcionalidades Comuns

### Filtros e Busca
- Busca em tempo real
- Filtros por status, data, usuário
- Ordenação customizável
- Paginação

### Estatísticas
- Cards de métricas principais
- Gráficos e indicadores visuais
- Comparações temporais
- KPIs relevantes por módulo

### Ações em Massa
- Seleção múltipla
- Operações em lote
- Confirmações de segurança
- Feedback de progresso

## 🚀 Próximos Passos

### Melhorias Planejadas
1. **Testes Automatizados** - Implementar testes unitários e E2E
2. **Internacionalização** - Suporte a múltiplos idiomas
3. **Temas** - Sistema de temas claro/escuro
4. **PWA** - Transformar em Progressive Web App
5. **Performance** - Lazy loading e otimizações

### Novos Módulos
1. **Reports** - Sistema avançado de relatórios
2. **Notifications** - Central de notificações
3. **Audit** - Auditoria detalhada do sistema
4. **API Management** - Gestão de APIs e documentação

## 📝 Contribuição

### Padrões de Código
- TypeScript obrigatório para novos componentes
- Componentes funcionais com hooks
- Props tipadas com interfaces
- Comentários JSDoc quando necessário

### Estrutura de Arquivos
```
ModuleName/
├── index.tsx              # Componente principal
├── components/            # Componentes específicos
├── hooks/                 # Hooks customizados
├── types/                 # Definições de tipos
└── SubModule/             # Sub-módulos
    ├── Index.tsx
    └── CreateEdit.tsx
```

### Nomenclatura
- **Componentes**: PascalCase (`UserProfile.tsx`)
- **Hooks**: camelCase com prefixo `use` (`useUserData.ts`)
- **Types**: PascalCase com sufixo `Type` (`UserType.ts`)
- **Constantes**: UPPER_SNAKE_CASE (`API_ENDPOINTS`)

---

**Status**: ✅ Todos os módulos faltantes foram implementados
**Cobertura**: 100% dos domínios backend têm correspondência no frontend
**Última atualização**: Dezembro 2024