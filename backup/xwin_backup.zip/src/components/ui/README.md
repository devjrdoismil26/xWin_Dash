# 🎨 xWin Dash - Componentes UI Avançados

Sistema de componentes UI moderno e inteligente para o xWin Dash, construído com React, TypeScript, Tailwind CSS e Framer Motion.

## 🚀 Componentes Principais

### 📊 IntelligentDashboard
Dashboard universal com métricas, gráficos e insights automáticos baseados em IA.

**Características:**
- ✅ Métricas inteligentes com tendências automáticas
- ✅ Insights baseados em IA
- ✅ Auto-refresh configurável
- ✅ Estados de loading e erro
- ✅ Animações suaves com Framer Motion
- ✅ Glassmorphism e design moderno

**Uso:**
```tsx
import IntelligentDashboard from '@/components/ui/IntelligentDashboard';

const metrics = [
  {
    id: 'revenue',
    title: 'Receita',
    value: 125000,
    previousValue: 100000,
    change: 25,
    changeType: 'increase',
    format: 'currency',
    status: 'success'
  }
];

<IntelligentDashboard
  title="Dashboard Executivo"
  metrics={metrics}
  insights={insights}
  onRefresh={handleRefresh}
  autoRefresh={true}
/>
```

### 🤖 IntelligentAutomation
Sistema completo de automação inteligente com regras, triggers e ações.

**Características:**
- ✅ Criação de regras de automação
- ✅ Triggers: eventos, agendamento, condições, webhooks
- ✅ Ações: email, notificações, webhooks, análise de IA
- ✅ Monitoramento de performance
- ✅ Templates de automação
- ✅ Analytics de uso

**Uso:**
```tsx
import IntelligentAutomation from '@/components/ui/IntelligentAutomation';

const rules = [
  {
    id: 'welcome-email',
    name: 'Email de Boas-vindas',
    trigger: { type: 'event', config: { event: 'user_registered' } },
    actions: [{ type: 'email', config: { template: 'welcome' } }],
    status: 'active'
  }
];

<IntelligentAutomation
  rules={rules}
  onCreateRule={handleCreateRule}
  onUpdateRule={handleUpdateRule}
  onToggleRule={handleToggleRule}
/>
```

### 🔔 IntelligentNotifications
Sistema avançado de notificações com IA, priorização e personalização.

**Características:**
- ✅ Notificações categorizadas e priorizadas
- ✅ Filtros avançados
- ✅ Ações personalizáveis
- ✅ Configurações de notificação
- ✅ Analytics de engajamento
- ✅ Horários silenciosos

**Uso:**
```tsx
import IntelligentNotifications from '@/components/ui/IntelligentNotifications';

const notifications = [
  {
    id: '1',
    title: 'Nova venda realizada',
    message: 'Venda de R$ 1.500,00 no produto X',
    type: 'success',
    priority: 'high',
    category: 'sales',
    timestamp: new Date().toISOString()
  }
];

<IntelligentNotifications
  notifications={notifications}
  onMarkAsRead={handleMarkAsRead}
  onArchive={handleArchive}
  onAction={handleAction}
/>
```

### 📈 AdvancedAnalytics
Sistema de analytics avançado com insights de IA e visualizações interativas.

**Características:**
- ✅ Métricas detalhadas com tendências
- ✅ Insights baseados em IA
- ✅ Segmentação de dados
- ✅ Visualizações interativas
- ✅ Exportação de dados
- ✅ Auto-refresh configurável

**Uso:**
```tsx
import AdvancedAnalytics from '@/components/ui/AdvancedAnalytics';

const metrics = [
  {
    id: 'conversion-rate',
    name: 'Taxa de Conversão',
    value: 3.2,
    change: 0.5,
    changeType: 'increase',
    format: 'percentage',
    category: 'conversion'
  }
];

<AdvancedAnalytics
  metrics={metrics}
  charts={charts}
  insights={insights}
  timeRange="7d"
  onTimeRangeChange={handleTimeRangeChange}
  onExport={handleExport}
/>
```

## 🎨 Design System

### 🎭 Glassmorphism
Todos os componentes utilizam o padrão glassmorphism moderno:

```css
backdrop-blur-xl bg-white/10 dark:bg-gray-900/10 
border border-white/20 dark:border-gray-700/20 
hover:bg-white/20 dark:hover:bg-gray-900/20 
transition-all duration-300 
hover:shadow-xl hover:shadow-blue-500/10
```

### 🎬 Animações
Sistema de animações unificado com Framer Motion:

```tsx
import { motion, AnimatePresence } from 'framer-motion';

// Entrada suave
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
exit={{ opacity: 0, y: -20 }}
transition={{ delay: index * 0.1 }}
```

### 🎨 Design Tokens
Sistema centralizado de tokens de design:

```tsx
import { ENHANCED_TRANSITIONS, VISUAL_EFFECTS } from './design-tokens';

// Transições padronizadas
className={ENHANCED_TRANSITIONS.button}
className={ENHANCED_TRANSITIONS.card}
```

## 🔧 Configuração

### 📦 Instalação
```bash
# Dependências principais
npm install react framer-motion lucide-react
npm install @radix-ui/react-* # Componentes base
npm install tailwindcss @tailwindcss/forms
```

### ⚙️ Configuração do Tailwind
```js
// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      backdropBlur: {
        xs: '2px',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
      }
    }
  }
}
```

## 📱 Responsividade

Todos os componentes são totalmente responsivos:

```tsx
// Grid responsivo
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

// Texto responsivo
<h1 className="text-2xl md:text-3xl lg:text-4xl font-bold">

// Espaçamento responsivo
<div className="p-4 md:p-6 lg:p-8">
```

## 🌙 Modo Escuro

Suporte completo ao modo escuro:

```tsx
// Classes condicionais
className="text-gray-900 dark:text-white bg-white dark:bg-gray-900"

// Cores adaptáveis
className="border-gray-200 dark:border-gray-700"
```

## 🎯 Acessibilidade

- ✅ Suporte completo a screen readers
- ✅ Navegação por teclado
- ✅ Contraste adequado
- ✅ Foco visível
- ✅ ARIA labels

## 🚀 Performance

- ✅ Lazy loading de componentes
- ✅ Memoização com useMemo/useCallback
- ✅ Virtualização de listas
- ✅ Code splitting automático
- ✅ Otimização de re-renders

## 📚 Exemplos de Uso

### Dashboard Completo
```tsx
import { 
  IntelligentDashboard, 
  IntelligentAutomation, 
  IntelligentNotifications,
  AdvancedAnalytics 
} from '@/components/ui';

function DashboardPage() {
  return (
    <div className="space-y-8">
      <IntelligentDashboard {...dashboardProps} />
      <AdvancedAnalytics {...analyticsProps} />
      <IntelligentAutomation {...automationProps} />
      <IntelligentNotifications {...notificationsProps} />
    </div>
  );
}
```

### Integração com Hooks
```tsx
import { useDashboard } from '@/hooks/useDashboard';
import IntelligentDashboard from '@/components/ui/IntelligentDashboard';

function MyDashboard() {
  const { metrics, insights, loading, refresh } = useDashboard();
  
  return (
    <IntelligentDashboard
      title="Meu Dashboard"
      metrics={metrics}
      insights={insights}
      loading={loading}
      onRefresh={refresh}
      autoRefresh={true}
    />
  );
}
```

## 🔄 Atualizações

### v1.0.0 - Lançamento Inicial
- ✅ IntelligentDashboard
- ✅ IntelligentAutomation  
- ✅ IntelligentNotifications
- ✅ AdvancedAnalytics
- ✅ Design System completo
- ✅ Glassmorphism
- ✅ Animações com Framer Motion

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🆘 Suporte

Para suporte e dúvidas:
- 📧 Email: suporte@xwindash.com
- 💬 Discord: [xWin Dash Community](https://discord.gg/xwindash)
- 📖 Documentação: [docs.xwindash.com](https://docs.xwindash.com)

---

**Desenvolvido com ❤️ pela equipe xWin Dash**