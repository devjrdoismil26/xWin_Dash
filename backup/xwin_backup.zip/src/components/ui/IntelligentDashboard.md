# 📊 IntelligentDashboard

Dashboard universal inteligente com métricas, gráficos e insights automáticos baseados em IA.

## 🎯 Visão Geral

O `IntelligentDashboard` é um componente avançado que combina métricas em tempo real, insights de IA e visualizações interativas em uma interface moderna e responsiva.

## ✨ Características

- 🧠 **Insights de IA**: Análise automática de dados e recomendações
- 📈 **Métricas Inteligentes**: Tendências automáticas e comparações
- 🔄 **Auto-refresh**: Atualização automática configurável
- 🎨 **Glassmorphism**: Design moderno com efeitos de vidro
- 📱 **Responsivo**: Adaptável a todos os dispositivos
- 🌙 **Modo Escuro**: Suporte completo ao tema escuro
- ⚡ **Performance**: Otimizado com memoização e lazy loading

## 📋 Props

### IntelligentDashboardProps

```typescript
interface IntelligentDashboardProps {
  title: string;                    // Título do dashboard
  description?: string;             // Descrição opcional
  metrics: Metric[];               // Array de métricas
  charts?: ChartData[];            // Dados para gráficos
  insights?: Insight[];            // Insights de IA
  loading?: boolean;               // Estado de carregamento
  error?: string;                  // Mensagem de erro
  onRefresh?: () => void;          // Callback para refresh
  onConfigure?: () => void;        // Callback para configuração
  className?: string;              // Classes CSS adicionais
  showInsights?: boolean;          // Mostrar seção de insights
  showCharts?: boolean;            // Mostrar seção de gráficos
  autoRefresh?: boolean;           // Auto-refresh habilitado
  refreshInterval?: number;        // Intervalo de refresh (ms)
}
```

### Metric

```typescript
interface Metric {
  id: string;                      // ID único da métrica
  title: string;                   // Título da métrica
  value: number;                   // Valor atual
  previousValue?: number;          // Valor anterior
  unit?: string;                   // Unidade de medida
  format?: 'number' | 'currency' | 'percentage'; // Formato
  trend?: 'up' | 'down' | 'stable'; // Tendência
  status?: 'success' | 'warning' | 'error' | 'info'; // Status
  icon?: React.ReactNode;          // Ícone opcional
  description?: string;            // Descrição
  actionable?: boolean;            // Se tem ação
  actionLabel?: string;            // Label da ação
  onAction?: () => void;           // Callback da ação
}
```

### Insight

```typescript
interface Insight {
  id: string;                      // ID único do insight
  type: 'success' | 'warning' | 'info' | 'action'; // Tipo
  title: string;                   // Título do insight
  description: string;             // Descrição
  impact?: 'high' | 'medium' | 'low'; // Impacto
  actionable?: boolean;            // Se tem ação
  actionLabel?: string;            // Label da ação
  onAction?: () => void;           // Callback da ação
}
```

## 🚀 Exemplos de Uso

### Exemplo Básico

```tsx
import IntelligentDashboard from '@/components/ui/IntelligentDashboard';

const metrics = [
  {
    id: 'revenue',
    title: 'Receita Total',
    value: 125000,
    previousValue: 100000,
    change: 25,
    changeType: 'increase',
    format: 'currency',
    status: 'success',
    description: 'Receita do último mês'
  },
  {
    id: 'users',
    title: 'Usuários Ativos',
    value: 1250,
    previousValue: 1000,
    change: 25,
    changeType: 'increase',
    format: 'number',
    status: 'success',
    description: 'Usuários ativos no último mês'
  }
];

const insights = [
  {
    id: 'growth-opportunity',
    type: 'opportunity',
    title: 'Oportunidade de Crescimento',
    description: 'Seus usuários cresceram 25% este mês. Considere expandir a infraestrutura.',
    impact: 'high',
    actionable: true,
    actionLabel: 'Ver detalhes',
    onAction: () => console.log('Ver detalhes do crescimento')
  }
];

function Dashboard() {
  return (
    <IntelligentDashboard
      title="Dashboard Executivo"
      description="Visão geral das principais métricas do negócio"
      metrics={metrics}
      insights={insights}
      autoRefresh={true}
      refreshInterval={30000}
    />
  );
}
```

### Exemplo com Callbacks

```tsx
import IntelligentDashboard from '@/components/ui/IntelligentDashboard';

function AdvancedDashboard() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRefresh = async () => {
    setLoading(true);
    setError(null);
    
    try {
      await fetchDashboardData();
    } catch (err) {
      setError('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  };

  const handleConfigure = () => {
    // Abrir modal de configuração
    console.log('Configurar dashboard');
  };

  return (
    <IntelligentDashboard
      title="Dashboard Avançado"
      metrics={metrics}
      insights={insights}
      loading={loading}
      error={error}
      onRefresh={handleRefresh}
      onConfigure={handleConfigure}
      showInsights={true}
      showCharts={true}
      autoRefresh={true}
    />
  );
}
```

### Exemplo com Métricas Acionáveis

```tsx
const actionableMetrics = [
  {
    id: 'low-stock',
    title: 'Estoque Baixo',
    value: 5,
    format: 'number',
    status: 'warning',
    description: 'Produtos com estoque baixo',
    actionable: true,
    actionLabel: 'Ver produtos',
    onAction: () => navigate('/products?filter=low-stock')
  },
  {
    id: 'pending-orders',
    title: 'Pedidos Pendentes',
    value: 12,
    format: 'number',
    status: 'info',
    description: 'Pedidos aguardando processamento',
    actionable: true,
    actionLabel: 'Processar',
    onAction: () => navigate('/orders?status=pending')
  }
];

<IntelligentDashboard
  title="Dashboard Operacional"
  metrics={actionableMetrics}
  showInsights={false}
/>
```

## 🎨 Customização

### Estilos Personalizados

```tsx
<IntelligentDashboard
  title="Meu Dashboard"
  metrics={metrics}
  className="my-custom-dashboard"
  showInsights={true}
  showCharts={false}
/>
```

```css
/* styles.css */
.my-custom-dashboard {
  --dashboard-primary: #3b82f6;
  --dashboard-secondary: #64748b;
  --dashboard-success: #10b981;
  --dashboard-warning: #f59e0b;
  --dashboard-error: #ef4444;
}

.my-custom-dashboard .metric-card {
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}
```

### Temas Personalizados

```tsx
const customTheme = {
  colors: {
    primary: '#8b5cf6',
    secondary: '#06b6d4',
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444'
  },
  spacing: {
    card: 'p-8',
    gap: 'gap-8'
  }
};

<IntelligentDashboard
  title="Dashboard Temático"
  metrics={metrics}
  theme={customTheme}
/>
```

## 🔧 Configuração Avançada

### Auto-refresh Personalizado

```tsx
const [refreshInterval, setRefreshInterval] = useState(30000);

const handleIntervalChange = (interval: number) => {
  setRefreshInterval(interval);
};

<IntelligentDashboard
  title="Dashboard Configurável"
  metrics={metrics}
  autoRefresh={true}
  refreshInterval={refreshInterval}
  onConfigure={() => setShowConfigModal(true)}
/>
```

### Estados de Loading Personalizados

```tsx
const CustomLoadingState = () => (
  <div className="flex items-center justify-center p-8">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    <span className="ml-2">Carregando métricas...</span>
  </div>
);

<IntelligentDashboard
  title="Dashboard com Loading Customizado"
  metrics={metrics}
  loading={loading}
  loadingComponent={<CustomLoadingState />}
/>
```

## 📊 Métricas Avançadas

### Métricas com Tendências

```tsx
const trendMetrics = [
  {
    id: 'conversion-rate',
    title: 'Taxa de Conversão',
    value: 3.2,
    previousValue: 2.8,
    change: 14.3,
    changeType: 'increase',
    format: 'percentage',
    trend: [
      { date: '2024-01-01', value: 2.5 },
      { date: '2024-01-02', value: 2.7 },
      { date: '2024-01-03', value: 2.8 },
      { date: '2024-01-04', value: 3.0 },
      { date: '2024-01-05', value: 3.2 }
    ]
  }
];
```

### Métricas com Ícones

```tsx
import { TrendingUp, Users, DollarSign, Target } from 'lucide-react';

const iconMetrics = [
  {
    id: 'revenue',
    title: 'Receita',
    value: 125000,
    format: 'currency',
    icon: <DollarSign className="w-6 h-6 text-green-600" />
  },
  {
    id: 'users',
    title: 'Usuários',
    value: 1250,
    format: 'number',
    icon: <Users className="w-6 h-6 text-blue-600" />
  },
  {
    id: 'conversion',
    title: 'Conversão',
    value: 3.2,
    format: 'percentage',
    icon: <Target className="w-6 h-6 text-purple-600" />
  }
];
```

## 🎯 Insights de IA

### Insights com Ações

```tsx
const actionableInsights = [
  {
    id: 'optimize-campaign',
    type: 'action',
    title: 'Otimizar Campanha',
    description: 'Sua campanha de email tem potencial de melhoria de 15% no CTR.',
    impact: 'medium',
    actionable: true,
    actionLabel: 'Otimizar Agora',
    onAction: () => openCampaignOptimizer()
  },
  {
    id: 'scale-infrastructure',
    type: 'warning',
    title: 'Escalar Infraestrutura',
    description: 'Seu tráfego está crescendo 20% ao mês. Considere escalar a infraestrutura.',
    impact: 'high',
    actionable: true,
    actionLabel: 'Ver Opções',
    onAction: () => openInfrastructureModal()
  }
];
```

## 🚀 Performance

### Otimizações Implementadas

- ✅ **Memoização**: Métricas e insights são memoizados
- ✅ **Lazy Loading**: Componentes carregados sob demanda
- ✅ **Virtualização**: Listas grandes são virtualizadas
- ✅ **Debouncing**: Auto-refresh com debounce
- ✅ **Code Splitting**: Componentes divididos em chunks

### Dicas de Performance

```tsx
// Use useMemo para métricas computadas
const processedMetrics = useMemo(() => {
  return metrics.map(metric => ({
    ...metric,
    displayValue: formatValue(metric.value, metric.format)
  }));
}, [metrics]);

// Use useCallback para funções
const handleRefresh = useCallback(async () => {
  await fetchData();
}, [fetchData]);

// Evite re-renders desnecessários
const MemoizedDashboard = React.memo(IntelligentDashboard);
```

## 🐛 Troubleshooting

### Problemas Comuns

**1. Métricas não atualizam**
```tsx
// Verifique se o auto-refresh está habilitado
<IntelligentDashboard
  autoRefresh={true}
  refreshInterval={30000}
  onRefresh={handleRefresh}
/>
```

**2. Insights não aparecem**
```tsx
// Verifique se showInsights está habilitado
<IntelligentDashboard
  insights={insights}
  showInsights={true}
/>
```

**3. Erro de formatação**
```tsx
// Verifique o formato das métricas
const metric = {
  id: 'revenue',
  title: 'Receita',
  value: 125000,
  format: 'currency', // 'number' | 'currency' | 'percentage'
  unit: 'BRL' // Opcional
};
```

## 📚 Recursos Adicionais

- [Design System](./design-tokens.ts)
- [Animações](./AdvancedAnimations.tsx)
- [Componentes Base](./Card.tsx)
- [Hooks Personalizados](../../hooks/)

## 🤝 Contribuição

Para contribuir com melhorias no IntelligentDashboard:

1. Fork o repositório
2. Crie uma branch para sua feature
3. Implemente as mudanças
4. Adicione testes
5. Documente as mudanças
6. Abra um Pull Request

---

**Desenvolvido com ❤️ pela equipe xWin Dash**