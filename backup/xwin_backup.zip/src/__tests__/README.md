# Test Suite Documentation

## Overview

This test suite provides comprehensive coverage for the xWin-Dash frontend application, including unit tests, integration tests, and component tests for all modules and UI components.

## Test Structure

```
src/__tests__/
├── components/           # UI Component tests
│   └── ui/              # Core UI components
├── modules/              # Module-specific tests
│   ├── Dashboard/        # Dashboard module tests
│   ├── AI/              # AI module tests
│   ├── Leads/           # Leads module tests
│   ├── Projects/        # Projects module tests
│   ├── EmailMarketing/  # Email Marketing module tests
│   ├── Analytics/       # Analytics module tests
│   ├── Workflows/       # Workflows module tests
│   ├── Users/           # Users module tests
│   ├── Settings/        # Settings module tests
│   ├── Activity/        # Activity module tests
│   ├── MediaLibrary/   # Media Library module tests
│   ├── SocialBuffer/   # Social Buffer module tests
│   ├── ADStool/        # ADS Tool module tests
│   └── Aura/           # Aura module tests
├── integration/         # Integration tests
└── README.md           # This file
```

## Test Configuration

### Vitest Configuration

The test suite uses Vitest with the following configuration:

- **Environment**: JSDOM for browser-like testing
- **Coverage**: V8 provider with 80% threshold
- **Setup**: Global test utilities and mocks
- **Plugins**: React plugin for JSX support

### Test Utilities

Located in `src/test-utils/`:

- **`setup.ts`**: Global test environment setup
- **`test-utils.tsx`**: Custom render function with providers
- **`mocks/`**: Mock handlers and server configuration

## Running Tests

### All Tests
```bash
npm run test
```

### Watch Mode
```bash
npm run test:watch
```

### Coverage Report
```bash
npm run test:coverage
```

### Specific Module
```bash
npm run test -- modules/Dashboard
```

### Specific Test File
```bash
npm run test -- Dashboard.test.tsx
```

## Test Categories

### 1. Module Tests

Each module includes comprehensive tests covering:

- **Rendering**: Component renders correctly
- **Data Display**: Data is displayed properly
- **CRUD Operations**: Create, Read, Update, Delete functionality
- **User Interactions**: Click, input, form submission
- **State Management**: Loading, error, success states
- **Responsiveness**: Mobile and desktop layouts
- **Theme Support**: Light and dark themes
- **Accessibility**: ARIA attributes and keyboard navigation

#### Example Module Test Structure:
```typescript
describe('ModuleName', () => {
  // Setup
  beforeEach(() => {
    // Mock hooks and setup
  });

  // Rendering tests
  it('should render module interface', async () => {
    // Test component rendering
  });

  // Data tests
  it('should display data correctly', async () => {
    // Test data display
  });

  // CRUD tests
  it('should handle creation', async () => {
    // Test create functionality
  });

  // Interaction tests
  it('should handle user interactions', async () => {
    // Test user interactions
  });

  // State tests
  it('should show loading state', async () => {
    // Test loading state
  });

  // Theme tests
  it('should support dark theme', async () => {
    // Test theme support
  });
});
```

### 2. Component Tests

UI component tests cover:

- **Props**: Different prop combinations
- **Variants**: Different visual variants
- **Sizes**: Different size options
- **States**: Disabled, loading, error states
- **Events**: Click, focus, blur, keyboard events
- **Accessibility**: ARIA attributes and roles
- **Theme**: Light and dark theme support

#### Example Component Test:
```typescript
describe('Button Component', () => {
  it('should render with different variants', () => {
    // Test variants
  });

  it('should handle click events', () => {
    // Test click handling
  });

  it('should be disabled when disabled prop is true', () => {
    // Test disabled state
  });
});
```

### 3. Integration Tests

Integration tests cover:

- **Authentication Flow**: Login, logout, redirects
- **Navigation**: Route changes and navigation
- **Data Flow**: API integration and state updates
- **User Workflows**: Complete user journeys

## Mock Strategy

### API Mocks

Using Mock Service Worker (MSW) for API mocking:

```typescript
// Mock API responses
export const handlers = [
  http.get('/api/dashboard/stats', () => {
    return HttpResponse.json({
      totalLeads: 1250,
      totalProjects: 45,
      totalRevenue: 125000,
      conversionRate: 12.5
    });
  }),
  // ... more handlers
];
```

### Hook Mocks

Each module's hooks are mocked with realistic data:

```typescript
vi.mock('@/modules/Dashboard/hooks/useDashboardData', () => ({
  useDashboardData: () => ({
    data: mockDashboardData,
    isLoading: false,
    error: null,
    refetch: vi.fn()
  })
}));
```

### Component Mocks

Complex components are mocked for isolation:

```typescript
vi.mock('@/modules/Dashboard/components/ExecutiveMasterDashboard', () => ({
  default: () => <div data-testid="executive-dashboard">Executive Dashboard</div>
}));
```

## Test Data

### Mock Data Structure

Each module has consistent mock data structure:

```typescript
const mockData = {
  // List items
  items: [
    {
      id: 1,
      name: 'Item Name',
      // ... other properties
      created_at: '2024-01-16T10:00:00Z',
      updated_at: '2024-01-16T10:00:00Z'
    }
  ],
  // Metadata
  meta: {
    total: 1,
    per_page: 15,
    current_page: 1
  },
  // States
  isLoading: false,
  error: null
};
```

## Best Practices

### 1. Test Organization
- Group related tests in `describe` blocks
- Use descriptive test names
- Follow AAA pattern (Arrange, Act, Assert)

### 2. Mock Management
- Mock at the module boundary
- Use realistic mock data
- Keep mocks simple and focused

### 3. Async Testing
- Use `waitFor` for async operations
- Test loading and error states
- Handle promise rejections

### 4. Accessibility Testing
- Test ARIA attributes
- Test keyboard navigation
- Test screen reader compatibility

### 5. Theme Testing
- Test both light and dark themes
- Verify theme-specific classes
- Test theme switching

## Coverage Goals

- **Statements**: 80%
- **Branches**: 80%
- **Functions**: 80%
- **Lines**: 80%

## Continuous Integration

Tests run automatically on:
- Pull requests
- Main branch pushes
- Scheduled runs

## Debugging Tests

### Common Issues

1. **Async Operations**: Use `waitFor` for async state changes
2. **Mock Data**: Ensure mock data matches expected structure
3. **Theme Classes**: Check for correct theme-specific classes
4. **Event Handling**: Verify event handlers are called correctly

### Debug Commands

```bash
# Run tests with verbose output
npm run test -- --reporter=verbose

# Run specific test with debug info
npm run test -- --reporter=verbose Dashboard.test.tsx

# Run tests in debug mode
npm run test -- --inspect-brk
```

## Contributing

When adding new tests:

1. Follow existing test patterns
2. Include comprehensive coverage
3. Use descriptive test names
4. Add appropriate mocks
5. Test edge cases and error states
6. Update documentation as needed

## Resources

- [Vitest Documentation](https://vitest.dev/)
- [React Testing Library](https://testing-library.com/docs/react-testing-library/intro/)
- [MSW Documentation](https://mswjs.io/)
- [Jest DOM Matchers](https://github.com/testing-library/jest-dom)