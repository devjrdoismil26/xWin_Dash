# Script de Build Unificado - xWin-Dash Frontend

## 🚀 Uso

```bash
npm run build
```

## 📋 Características

- **Execução Ordenada**: Módulos são construídos em ordem específica para evitar problemas de dependência
- **Build Modular**: Cada módulo é construído separadamente
- **Relatório Detalhado**: Gera manifesto com status de cada módulo
- **Limpeza Automática**: Remove builds anteriores automaticamente
- **Configuração Dinâmica**: Cria configurações Vite específicas para cada módulo

## 📦 Ordem de Execução

1. **Core** (primeiro)
2. **Users** → **Settings** → **Dashboard** (módulos base)
3. **Projects** → **Leads** → **Products** → **Analytics** (módulos de negócio)
4. **AI** → **EmailMarketing** → **SocialBuffer** → **Workflows** (módulos avançados)
5. **ADStool** → **Activity** → **Aura** → **MediaLibrary** (módulos especializados)

## 📁 Estrutura de Saída

```
dist/
├── core/                    # Core da aplicação
│   ├── main.js             # Bundle principal
│   ├── app.js              # App component
│   ├── main-*.css          # Estilos
│   └── *-vendor-*.js       # Chunks de dependências
├── Users/                   # Módulo Users
│   └── Users.js
├── Dashboard/               # Módulo Dashboard
│   └── Dashboard.js
└── build-manifest.json      # Manifesto do build
```

## 🔧 Configurações

- **Target**: ES2015
- **Minify**: Desabilitado (para builds mais rápidos)
- **Sourcemap**: Desabilitado
- **Chunk Size Warning**: 2000KB
- **External**: Exclui arquivos de teste e documentação

## 📊 Relatório

O script gera um relatório final com:
- Tempo total de execução
- Número de módulos construídos com sucesso
- Módulos com erro (se houver)
- Tamanhos dos builds
- Manifesto detalhado em JSON

## 🚨 Troubleshooting

### Erro: "module not found"
- Verifique se o módulo possui `index.tsx`
- Confirme se as dependências estão instaladas

### Build muito lento
- O script executa módulos sequencialmente para evitar conflitos
- Para builds mais rápidos, use `npm run build:standard`

### Módulos com erro
- Verifique o manifesto em `dist/build-manifest.json`
- Cada módulo é construído independentemente